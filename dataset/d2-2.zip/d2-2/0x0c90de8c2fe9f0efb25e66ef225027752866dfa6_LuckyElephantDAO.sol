/**
 *Submitted for verification at Etherscan.io on 2024-09-29
*/

// SPDX-License-Identifier: MIT

// File: @openzeppelin/contracts/utils/Context.sol


// OpenZeppelin Contracts (last updated v5.0.1) (utils/Context.sol)

pragma solidity ^0.8.20;

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }

    function _contextSuffixLength() internal view virtual returns (uint256) {
        return 0;
    }
}

// File: @openzeppelin/contracts/access/Ownable.sol


// OpenZeppelin Contracts (last updated v5.0.0) (access/Ownable.sol)

pragma solidity ^0.8.20;


/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * The initial owner is set to the address provided by the deployer. This can
 * later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
abstract contract Ownable is Context {
    address private _owner;

    /**
     * @dev The caller account is not authorized to perform an operation.
     */
    error OwnableUnauthorizedAccount(address account);

    /**
     * @dev The owner is not a valid owner account. (eg. `address(0)`)
     */
    error OwnableInvalidOwner(address owner);

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    /**
     * @dev Initializes the contract setting the address provided by the deployer as the initial owner.
     */
    constructor(address initialOwner) {
        if (initialOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(initialOwner);
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if the sender is not the owner.
     */
    function _checkOwner() internal view virtual {
        if (owner() != _msgSender()) {
            revert OwnableUnauthorizedAccount(_msgSender());
        }
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby disabling any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        if (newOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(newOwner);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

// File: @openzeppelin/contracts/utils/ReentrancyGuard.sol


// OpenZeppelin Contracts (last updated v5.0.0) (utils/ReentrancyGuard.sol)

pragma solidity ^0.8.20;

/**
 * @dev Contract module that helps prevent reentrant calls to a function.
 *
 * Inheriting from `ReentrancyGuard` will make the {nonReentrant} modifier
 * available, which can be applied to functions to make sure there are no nested
 * (reentrant) calls to them.
 *
 * Note that because there is a single `nonReentrant` guard, functions marked as
 * `nonReentrant` may not call one another. This can be worked around by making
 * those functions `private`, and then adding `external` `nonReentrant` entry
 * points to them.
 *
 * TIP: If you would like to learn more about reentrancy and alternative ways
 * to protect against it, check out our blog post
 * https://blog.openzeppelin.com/reentrancy-after-istanbul/[Reentrancy After Istanbul].
 */
abstract contract ReentrancyGuard {
    // Booleans are more expensive than uint256 or any type that takes up a full
    // word because each write operation emits an extra SLOAD to first read the
    // slot's contents, replace the bits taken up by the boolean, and then write
    // back. This is the compiler's defense against contract upgrades and
    // pointer aliasing, and it cannot be disabled.

    // The values being non-zero value makes deployment a bit more expensive,
    // but in exchange the refund on every call to nonReentrant will be lower in
    // amount. Since refunds are capped to a percentage of the total
    // transaction's gas, it is best to keep them low in cases like this one, to
    // increase the likelihood of the full refund coming into effect.
    uint256 private constant NOT_ENTERED = 1;
    uint256 private constant ENTERED = 2;

    uint256 private _status;

    /**
     * @dev Unauthorized reentrant call.
     */
    error ReentrancyGuardReentrantCall();

    constructor() {
        _status = NOT_ENTERED;
    }

    /**
     * @dev Prevents a contract from calling itself, directly or indirectly.
     * Calling a `nonReentrant` function from another `nonReentrant`
     * function is not supported. It is possible to prevent this from happening
     * by making the `nonReentrant` function external, and making it call a
     * `private` function that does the actual work.
     */
    modifier nonReentrant() {
        _nonReentrantBefore();
        _;
        _nonReentrantAfter();
    }

    function _nonReentrantBefore() private {
        // On the first call to nonReentrant, _status will be NOT_ENTERED
        if (_status == ENTERED) {
            revert ReentrancyGuardReentrantCall();
        }

        // Any calls to nonReentrant after this point will fail
        _status = ENTERED;
    }

    function _nonReentrantAfter() private {
        // By storing the original value once again, a refund is triggered (see
        // https://eips.ethereum.org/EIPS/eip-2200)
        _status = NOT_ENTERED;
    }

    /**
     * @dev Returns true if the reentrancy guard is currently set to "entered", which indicates there is a
     * `nonReentrant` function in the call stack.
     */
    function _reentrancyGuardEntered() internal view returns (bool) {
        return _status == ENTERED;
    }
}

// File: @openzeppelin/contracts/utils/Pausable.sol


// OpenZeppelin Contracts (last updated v5.0.0) (utils/Pausable.sol)

pragma solidity ^0.8.20;


/**
 * @dev Contract module which allows children to implement an emergency stop
 * mechanism that can be triggered by an authorized account.
 *
 * This module is used through inheritance. It will make available the
 * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
 * the functions of your contract. Note that they will not be pausable by
 * simply including this module, only once the modifiers are put in place.
 */
abstract contract Pausable is Context {
    bool private _paused;

    /**
     * @dev Emitted when the pause is triggered by `account`.
     */
    event Paused(address account);

    /**
     * @dev Emitted when the pause is lifted by `account`.
     */
    event Unpaused(address account);

    /**
     * @dev The operation failed because the contract is paused.
     */
    error EnforcedPause();

    /**
     * @dev The operation failed because the contract is not paused.
     */
    error ExpectedPause();

    /**
     * @dev Initializes the contract in unpaused state.
     */
    constructor() {
        _paused = false;
    }

    /**
     * @dev Modifier to make a function callable only when the contract is not paused.
     *
     * Requirements:
     *
     * - The contract must not be paused.
     */
    modifier whenNotPaused() {
        _requireNotPaused();
        _;
    }

    /**
     * @dev Modifier to make a function callable only when the contract is paused.
     *
     * Requirements:
     *
     * - The contract must be paused.
     */
    modifier whenPaused() {
        _requirePaused();
        _;
    }

    /**
     * @dev Returns true if the contract is paused, and false otherwise.
     */
    function paused() public view virtual returns (bool) {
        return _paused;
    }

    /**
     * @dev Throws if the contract is paused.
     */
    function _requireNotPaused() internal view virtual {
        if (paused()) {
            revert EnforcedPause();
        }
    }

    /**
     * @dev Throws if the contract is not paused.
     */
    function _requirePaused() internal view virtual {
        if (!paused()) {
            revert ExpectedPause();
        }
    }

    /**
     * @dev Triggers stopped state.
     *
     * Requirements:
     *
     * - The contract must not be paused.
     */
    function _pause() internal virtual whenNotPaused {
        _paused = true;
        emit Paused(_msgSender());
    }

    /**
     * @dev Returns to normal state.
     *
     * Requirements:
     *
     * - The contract must be paused.
     */
    function _unpause() internal virtual whenPaused {
        _paused = false;
        emit Unpaused(_msgSender());
    }
}

// File: contracts/LuckyElephantDAO.sol


pragma solidity ^0.8.26;




/**
 * @title LuckyElephantDAO
 * @dev A governance contract where only NFT holders from allowed collections can propose, vote,
 * and participate in DAO activities such as NFT investments, donations, and selling NFTs.
 */
interface ILuckyElephantNFT {
    /// @dev balanceOf returns the number of NFTs owned by the given address
    function balanceOf(address owner) external view returns (uint256);
}

contract LuckyElephantDAO is Ownable, Pausable, ReentrancyGuard {
    ILuckyElephantNFT public luckyElephantNFT;
    address public immutable communityWallet;  // Gnosis Safe community wallet

    uint256 public proposalFee = 0.01 ether;   // Set the proposal fee amount

    // Define a list of allowed NFT collections that can participate in governance
    mapping(address => bool) public allowedCollections;
    address[] public nftCollections; // Track the added NFT collections

    // Create a struct for Governance Proposals
    struct Proposal {
        string description; // A description of the proposal
        uint256 deadline; // UNIX timestamp for when voting ends
        uint256 yayVotes; // Count of "yay" votes
        uint256 nayVotes; // Count of "nay" votes
        bool executed; // Has the proposal been executed?
        bool proposalPassed; // Did the proposal pass or not?
        ProposalType proposalType; // Type of the proposal (general, investment, etc.)
        address targetNFTCollection; // Used for adding/removing NFT collections
        mapping(uint256 => bool) voters; // Keep track of whether a tokenId has voted
    }

    // Enum for different types of proposals in the ecosystem
    enum ProposalType {
        General,
        Investment,
        Donation,
        NFTSale,
        SocialFiFeature,
        ClothingLine,
        AddNFTCollection,
        RemoveNFTCollection
    }

    // Enum for the vote type
    enum Vote {
        YAY,
        NAY
    }

    mapping(uint256 => Proposal) public proposals; // Track all proposals
    uint256 public numProposals; // Track the number of proposals

    // Modifier to allow only NFT holders from approved collections to interact with governance features
    modifier onlyNFTHolder() {
        require(isNFTHolder(msg.sender), "NOT_A_DAO_MEMBER");
        _;
    }

    // Modifier to check that the proposal is still active
    modifier activeProposalOnly(uint256 proposalIndex) {
        require(proposals[proposalIndex].deadline > block.timestamp, "PROPOSAL_DEADLINE_EXCEEDED");
        _;
    }

    // Modifier to check that the proposal has passed the deadline and not been executed
    modifier inactiveProposalOnly(uint256 proposalIndex) {
        require(proposals[proposalIndex].deadline <= block.timestamp, "PROPOSAL_DEADLINE_NOT_EXCEEDED");
        require(!proposals[proposalIndex].executed, "PROPOSAL_ALREADY_EXECUTED");
        _;
    }

    // Constructor to set the NFT contract address, community wallet, and call the Ownable constructor
    constructor(address _luckyElephantNFT, address _communityWallet) Ownable(msg.sender) {
        luckyElephantNFT = ILuckyElephantNFT(_luckyElephantNFT);
        communityWallet = _communityWallet;
    }

    /**
     * @dev Set the fee for creating a proposal
     * @param _fee The fee amount in wei.
     */
    function setProposalFee(uint256 _fee) external onlyOwner {
        proposalFee = _fee;
    }

    /**
     * @dev Create a new proposal. Requires a fee to be paid.
     * @param _description The description of the proposal.
     * @param _proposalType The type of the proposal.
     * @param _targetNFTCollection The target NFT collection for Add/Remove NFT Collection proposals.
     * @return The index of the created proposal.
     */
    function createProposal(
        string memory _description,
        ProposalType _proposalType,
        address _targetNFTCollection
    ) external payable onlyNFTHolder whenNotPaused returns (uint256) {
        require(msg.value >= proposalFee, "INSUFFICIENT_PROPOSAL_FEE");

        Proposal storage proposal = proposals[numProposals];
        proposal.description = _description;
        proposal.deadline = block.timestamp + 5 minutes; // Set the voting period to 5 minutes (adjust as needed)
        proposal.proposalType = _proposalType;
        proposal.targetNFTCollection = _targetNFTCollection;

        numProposals++;
        return numProposals - 1;
    }

    /**
     * @dev Vote on a proposal.
     * @param proposalIndex The index of the proposal to vote on.
     * @param vote The type of vote (YAY or NAY).
     */
    function voteOnProposal(uint256 proposalIndex, Vote vote)
        external
        onlyNFTHolder
        activeProposalOnly(proposalIndex)
    {
        Proposal storage proposal = proposals[proposalIndex];

        uint256 voterNFTBalance = luckyElephantNFT.balanceOf(msg.sender);
        uint256 numVotes = 0;

        // Calculate how many votes the user has (based on NFT holdings)
        for (uint256 i = 0; i < voterNFTBalance; i++) {
            if (!proposal.voters[i]) {
                numVotes++;
                proposal.voters[i] = true;
            }
        }
        require(numVotes > 0, "ALREADY_VOTED");

        if (vote == Vote.YAY) {
            proposal.yayVotes += numVotes;
        } else {
            proposal.nayVotes += numVotes;
        }
    }

    /**
     * @dev Execute a proposal after the voting period has ended.
     * @param proposalIndex The index of the proposal to execute.
     */
    function executeProposal(uint256 proposalIndex)
        external
        onlyNFTHolder
        inactiveProposalOnly(proposalIndex)
        nonReentrant
    {
        Proposal storage proposal = proposals[proposalIndex];

        // Determine if the proposal passed
        if (proposal.yayVotes > proposal.nayVotes) {
            proposal.proposalPassed = true;

            // If the proposal type is AddNFTCollection or RemoveNFTCollection, handle it
            if (proposal.proposalType == ProposalType.AddNFTCollection) {
                addNFTCollection(proposal.targetNFTCollection);
            } else if (proposal.proposalType == ProposalType.RemoveNFTCollection) {
                removeNFTCollection(proposal.targetNFTCollection);
            }
        }

        proposal.executed = true;
    }

    /**
     * @dev Add an NFT collection to the allowed list.
     * @param _nftCollection The address of the NFT collection to add.
     */
    function addNFTCollection(address _nftCollection) internal {
        require(!allowedCollections[_nftCollection], "COLLECTION_ALREADY_ADDED");
        allowedCollections[_nftCollection] = true;
        nftCollections.push(_nftCollection);
    }

    /**
     * @dev Remove an NFT collection from the allowed list.
     * @param _nftCollection The address of the NFT collection to remove.
     */
    function removeNFTCollection(address _nftCollection) internal {
        require(allowedCollections[_nftCollection], "COLLECTION_NOT_FOUND");
        allowedCollections[_nftCollection] = false;

        // Remove from the array of NFT collections
        for (uint256 i = 0; i < nftCollections.length; i++) {
            if (nftCollections[i] == _nftCollection) {
                nftCollections[i] = nftCollections[nftCollections.length - 1];
                nftCollections.pop();
                break;
            }
        }
    }

    /**
     * @dev Withdraw funds from the DAO to the Gnosis Safe community wallet.
     */
    function withdrawFunds() external onlyOwner {
        payable(communityWallet).transfer(address(this).balance);
    }

    // Check if a user holds an NFT from any allowed collection
    function isNFTHolder(address user) public view returns (bool) {
        for (uint256 i = 0; i < nftCollections.length; i++) {
            if (ILuckyElephantNFT(nftCollections[i]).balanceOf(user) > 0) {
                return true;
            }
        }
        return false;
    }

    // Allow receiving Ether
    receive() external payable {}
    fallback() external payable {}
}