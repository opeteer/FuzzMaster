// SPDX-License-Identifier: MIT
pragma solidity ^0.8.4;

import {VaultManager, ERC721} from "../vault/VaultManager.sol";

/// @notice Vesting vault manager class.
contract VestingVaultManager is VaultManager {
    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                         CONSTANTS                          */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    /// @dev The role flag for admin.
    uint256 public constant ADMIN_ROLE = _ROLE_0;

    /// @dev Initial vesting mode.
    uint8 internal constant _VESTING_MODE_NONE = 0;

    /// @dev Either in cliff, or in regular vesting.
    uint8 internal constant _VESTING_MODE_REGULAR = 1;

    /// @dev In early vesting.
    uint8 internal constant _VESTING_MODE_EARLY = 2;

    /// @dev For safety, in case of a typo.
    uint32 internal constant _VESTING_DURATION_MAX = 365 days;

    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                       CUSTOM ERRORS                        */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    /// @dev One non-transferable vault per account.
    error Soulbound();

    /// @dev The value is locked.
    error Locked();

    /// @dev The operation is not allowed for the current vesting mode.
    error InvalidVestingMode();

    /// @dev Cannot start early vesting when vesting has already started.
    error VestingAlreadyStarted();

    /// @dev The vesting duration must be greater than zero and
    /// less than or equal to `_VESTING_DURATION_MAX`.
    error InvalidVestingDuration();

    /// @dev Withdrawn too much.
    error OverWithdrawn();

    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                          STORAGE                           */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    /// @dev Address of the vault's proxy.
    address public vaultProxy;

    /// @dev Whether the cliff duration is locked.
    bool public cliffDurationLocked;

    /// @dev Whether the vesting duration is locked.
    bool public vestingDurationLocked;

    /// @dev Whether the early vesting duration is locked.
    bool public earlyVestingDurationLocked;

    /// @dev Whether the vault's proxy is locked.
    bool public vaultProxyLocked;

    /// @dev The vesting mode.
    uint8 public vestingMode;

    /// @dev The start of the vesting period.
    uint32 public vestingStart;

    /// @dev The end of the vesting period.
    uint32 public vestingEnd;

    /// @dev The cliff duration.
    uint32 public cliffDuration;

    /// @dev The regular vesting duration.
    uint32 public vestingDuration;

    /// @dev The early vesting duration.
    uint32 public earlyVestingDuration;

    /// @dev Mapping of `holder` to their initially locked Asterix ERC20 amount.
    mapping(address => uint256) public initialLockedAsterixERC20Amount;

    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                        CONSTRUCTOR                         */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    constructor() {
        // Use an average of 30 days in a month.
        cliffDuration = 1 days * 30 * 6; // 6 months.
        vestingDuration = 1 days * 30 * 10; // 10 months.
        earlyVestingDuration = 1 days * 30 * 8; // 8 months;
        _initializeVaultManager(
            msg.sender == 0x0000000000FFe8B47B3e2130213B802212439497 ? tx.origin : msg.sender
        );
    }

    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                      VAULT OPERATIONS                      */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    /// @dev Returns the amount of Asterix ERC20 that `holder` can currently withdraw.
    function withdrawableAsterixERC20(address holder)
        public
        view
        virtual
        returns (uint256 result)
    {
        address vault = vaultOf(holder);
        if (vault == address(0)) return 0;
        // `vaultBalance > requiredBalance ? vaultBalance - requiredBalance : 0`.
        return _zeroFloorSub(_balanceOf(ASTERIX, vault), requiredAsterixERC20Balance(holder));
    }

    /// @dev Returns the required balance in the vault of `holder`.
    function requiredAsterixERC20Balance(address holder)
        public
        view
        virtual
        returns (uint256 result)
    {
        // If the cliff has not started, the `holder` is still allowed to withdraw
        // all of their Asterix balance in the vault, in case of an over deposit by mistake.
        if (vestingMode != _VESTING_MODE_NONE) {
            result = initialLockedAsterixERC20Amount[holder]; // Within uint96.
            uint256 end = vestingEnd;
            uint256 start = vestingStart;
            if (block.timestamp >= start) {
                unchecked {
                    // `((end > timestamp ? end - time : 0) * result) / (end - start)`.
                    result = _rawDiv(_zeroFloorSub(end, block.timestamp) * result, end - start);
                }
            }
        }
    }

    /// @dev Override to return the vault proxy for use in `_createVault`.
    function _vaultProxy() internal view virtual override(VaultManager) returns (address) {
        return vaultProxy;
    }

    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                      ADMIN OPERATIONS                      */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    /// @dev Locks the vault proxy.
    function lockVaultProxy() public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        vaultProxyLocked = true;
    }

    /// @dev Sets the vault proxy.
    function setVaultProxy(address proxy) public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        if (vaultProxyLocked) revert Locked();
        vaultProxy = proxy;
    }

    /// @dev Locks the cliff duration.
    function lockCliffDuration() public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        cliffDurationLocked = true;
    }

    /// @dev Set the cliff duration.
    function setCliffDuration(uint32 value) public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        if (cliffDurationLocked) revert Locked();
        if (value == 0 || value > _VESTING_DURATION_MAX) revert InvalidVestingDuration();
        cliffDuration = value;
    }

    /// @dev Locks the vesting duration.
    function lockVestingDuration() public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        vestingDurationLocked = true;
    }

    /// @dev Sets the vesting duration.
    function setVestingDuration(uint32 value) public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        if (vestingDurationLocked) revert Locked();
        if (value == 0 || value > _VESTING_DURATION_MAX) revert InvalidVestingDuration();
        vestingDuration = value;
    }

    /// @dev Locks the early vesting duration.
    function lockEarlyVestingDuration() public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        earlyVestingDurationLocked = true;
    }

    /// @dev Sets the early vesting duration.
    function setEarlyVestingDuration(uint32 value) public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        if (earlyVestingDurationLocked) revert Locked();
        if (value == 0 || value > _VESTING_DURATION_MAX) revert InvalidVestingDuration();
        earlyVestingDuration = value;
    }

    /// @dev Sets the cliff, which will lead to the regular vesting.
    function startCliff() public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        if (vestingMode != _VESTING_MODE_NONE) revert InvalidVestingMode();
        uint32 start = uint32(block.timestamp) + cliffDuration;
        vestingMode = _VESTING_MODE_REGULAR;
        vestingStart = start;
        vestingEnd = start + vestingDuration;
        cliffDurationLocked = true;
        vestingDurationLocked = true;
    }

    /// @dev Starts the early vesting period.
    function startEarlyVesting() public virtual onlyOwnerOrRoles(ADMIN_ROLE) {
        if (vestingMode != _VESTING_MODE_REGULAR) revert InvalidVestingMode();
        if (block.timestamp >= vestingStart) revert VestingAlreadyStarted();
        vestingMode = _VESTING_MODE_EARLY;
        vestingStart = uint32(block.timestamp);
        vestingEnd = uint32(block.timestamp) + earlyVestingDuration;
        earlyVestingDurationLocked = true;
    }

    /// @dev Directly resets the vesting state for testing purposes.
    function directResetVestingState(uint8 mode, uint32 start, uint32 end)
        public
        onlyOwnerOrRoles(ADMIN_ROLE)
    {
        _requireOnlyTestnet();
        require(end >= start + 1, "`end` must be >= `start + 1`.");
        vestingMode = mode;
        vestingStart = start;
        vestingEnd = end;
        cliffDurationLocked = false;
        vestingDurationLocked = false;
        earlyVestingDurationLocked = false;
    }

    /// @dev Directly resets the vesting state for testing purposes.
    function directResetVestingState() public onlyOwnerOrRoles(ADMIN_ROLE) {
        _requireOnlyTestnet();
        vestingMode = _VESTING_MODE_NONE;
        vestingStart = 0;
        vestingEnd = 0;
        cliffDurationLocked = false;
        vestingDurationLocked = false;
        earlyVestingDurationLocked = false;
    }

    /// @dev Directly resets the vesting state for testing purposes.
    function directSetInitialLockedAsterixERC20Amount(address holder, uint256 amount)
        public
        onlyOwnerOrRoles(ADMIN_ROLE)
    {
        _requireOnlyTestnet();
        require(amount < 2 ** 96, "`amount` too big.");
        initialLockedAsterixERC20Amount[holder] = amount;
    }

    /// @dev Reverts if the chain is not Sepolia / Holesky testnet.
    function _requireOnlyTestnet() private view {
        require(
            block.chainid == 17000 || block.chainid == 11155111,
            "Only on Sepolia / Holesky testnet."
        );
    }

    /*«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-«-*/
    /*                         OVERRIDES                          */
    /*-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»-»*/

    /// @dev Updates the initial locked amount for `holder`.
    function _afterDepositAsterixFor(address holder) internal virtual override(VaultManager) {
        uint256 currentBalance = _balanceOf(ASTERIX, vaultOf(holder));
        // Before vesting starts, any deposit via the VestingVaultManager will update
        // `initialLockedAsterixERC20Amount` to the Asterix ERC20 balance of the vault.
        if (
            vestingMode == _VESTING_MODE_NONE || block.timestamp < vestingStart
                || (currentBalance > initialLockedAsterixERC20Amount[holder] && msg.sender == owner())
        ) {
            initialLockedAsterixERC20Amount[holder] = currentBalance;
        }
    }

    /// @dev Checks that there is enough ERC20 locked in the caller's vault.
    /// This override ensures that during the cliff and vesting phases,
    /// the `holder` cannot overWithdraw.
    function _afterWithdrawAsterix() internal virtual override(VaultManager) {
        address vault = vaultOf(msg.sender);
        if (vestingMode == _VESTING_MODE_NONE) {
            // Before vesting starts, any withdrawal via the VestingVaultManager will update
            // `initialLockedAsterixERC20Amount` to the Asterix ERC20 balance of the vault.
            initialLockedAsterixERC20Amount[msg.sender] = _balanceOf(ASTERIX, vault);
        } else {
            uint256 requiredBalance = requiredAsterixERC20Balance(msg.sender);
            if (_balanceOf(ASTERIX, vault) < requiredBalance) revert OverWithdrawn();
        }
    }

    /// @dev Override for account-bound tokens.
    function setSingleTransferEnabled(bool) public virtual override(VaultManager) {
        if (true) revert Soulbound();
    }

    /// @dev Override for account-bound tokens.
    function transferFrom(address, address, uint256) public payable virtual override(ERC721) {
        if (true) revert Soulbound();
    }

    /// @dev Override for account-bound tokens.
    function approve(address, uint256) public payable virtual override(ERC721) {
        if (true) revert Soulbound();
    }

    /// @dev Override for account-bound tokens.
    function getApproved(uint256) public view virtual override(ERC721) returns (address) {
        return address(0);
    }

    /// @dev Override for account-bound tokens.
    function setApprovalForAll(address, bool) public virtual override(ERC721) {
        if (true) revert Soulbound();
    }

    /// @dev Override for account-bound tokens.
    function isApprovedForAll(address, address)
        public
        view
        virtual
        override(ERC721)
        returns (bool)
    {
        return false;
    }
}