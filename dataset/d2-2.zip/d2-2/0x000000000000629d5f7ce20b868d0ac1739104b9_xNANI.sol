// ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘ ⌘
// SPDX-License-Identifier: AGPL-3.0-only
pragma solidity 0.8.27;

/// @notice Simple nontransferable xNANI voting token.
/// @dev Includes method for staking and unstaking NANI.
/// @custom:lex Nani DAO is chartered as progressive DUNA
/// (https://github.com/NaniDAO/NaniDAO)
/// @author nani.eth (Nani DAO)
contract xNANI {
    event Transfer(address indexed from, address indexed to, uint256 amount);
    event Approval(address indexed from, address indexed to, uint256 amount);

    string public constant name = "xNANI";
    string public constant symbol = "xNANI";
    uint256 public constant decimals = 18;
    address public constant NANI = 0x00000000000007C8612bA63Df8DdEfD9E6077c97;
    
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function approve(address to, uint256 amount) public returns (bool) {
        allowance[msg.sender][to] = amount;
        emit Approval(msg.sender, to, amount);
        return true;
    }

    // STAKING

    function stake(uint256 amount) public {
        uint256 totalNani = IToken(NANI).balanceOf(this);
        uint256 totalShares = totalSupply;
        if (totalShares == 0 || totalNani == 0) {
            unchecked {
                balanceOf[msg.sender] += amount;
                totalSupply += amount;
                emit Transfer(address(0), msg.sender, amount);
            }
        } else {
            unchecked {
                uint256 what = amount * totalShares / totalNani;
                balanceOf[msg.sender] += what;
                totalSupply += what;
                emit Transfer(address(0), msg.sender, what);
            }
        }
        IToken(NANI).transferFrom(msg.sender, this, amount);
    }

    function unstake(uint256 share) public {
        uint256 what = share * IToken(NANI).balanceOf(this) / totalSupply;
        balanceOf[msg.sender] -= share;
        unchecked {
            totalSupply -= share;
        }
        IToken(NANI).transfer(msg.sender, what);
        emit Transfer(msg.sender, address(0), share);
    }

    function stakedBalance(address user) public view returns (uint256) {
        return balanceOf[user] * IToken(NANI).balanceOf(this) / totalSupply;
    }

    // NONTRANSFERABLE

    function transfer(address, uint256) public returns (bool) {} // Nope.
    function transferFrom(address, address, uint256) public returns (bool) {}
}

/// @notice Simple token interaction interface.
interface IToken {
    function balanceOf(xNANI) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, xNANI, uint256) external returns (bool);
}