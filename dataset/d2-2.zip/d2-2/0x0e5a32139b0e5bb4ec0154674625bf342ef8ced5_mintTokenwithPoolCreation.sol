/**
 *Submitted for verification at Etherscan.io on 2024-10-17
*/

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

/*
https://t.me/+ECVvTPZcpNNhOTUx
https://x.com/OfficialUranos

Mint Price: 0.025
*/

// Interfaces

interface IUniswapV2Router {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function addLiquidity(
        address tokenA,
        address tokenB,
        uint256 amountADesired,
        uint256 amountBDesired,
        uint256 amountAMin,
        uint256 amountBMin,
        address to,
        uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);
}

// Ownable's Contract

abstract contract Ownable {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _transferOwnership(msg.sender);
    }

    function owner() public view virtual returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(owner() == msg.sender, "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _transferOwnership(newOwner);
    }

    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

abstract contract ERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
    }

    function name() public view virtual returns (string memory) {
        return _name;
    }

    function symbol() public view virtual returns (string memory) {
        return _symbol;
    }

    function decimals() public view virtual returns (uint8) {
        return 18;
    }

    function totalSupply() public view virtual returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) public view virtual returns (uint256) {
        return _balances[account];
    }

    function transfer(address to, uint256 amount) public virtual returns (bool) {
        address owner = msg.sender;
        _transfer(owner, to, amount);
        return true;
    }

    function allowance(address owner, address spender) public view virtual returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 amount) public virtual returns (bool) {
        address owner = msg.sender;
        _approve(owner, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public virtual returns (bool) {
        address spender = msg.sender;
        _spendAllowance(from, spender, amount);
        _transfer(from, to, amount);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal virtual {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");
        uint256 fromBalance = _balances[from];
        require(fromBalance >= amount, "ERC20: transfer amount exceeds balance");
        unchecked {
            _balances[from] = fromBalance - amount;
            _balances[to] += amount;
        }
        emit Transfer(from, to, amount);
    }

    function _mint(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: mint to the zero address");
        _totalSupply += amount;
        unchecked {
            _balances[account] += amount;
        }
        emit Transfer(address(0), account, amount);
    }

    function _burn(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: burn from the zero address");
        uint256 accountBalance = _balances[account];
        require(accountBalance >= amount, "ERC20: burn amount exceeds balance");
        unchecked {
            _balances[account] = accountBalance - amount;
            _totalSupply -= amount;
        }
        emit Transfer(account, address(0), amount);
    }

    function _approve(address owner, address spender, uint256 amount) internal virtual {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");
        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function _spendAllowance(address owner, address spender, uint256 amount) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= amount, "ERC20: insufficient allowance");
            unchecked {
                _approve(owner, spender, currentAllowance - amount);
            }
        }
    }
}

contract WrappedEther is ERC20 {
    event Deposit(address indexed account, uint256 amount);
    event Withdrawal(address indexed account, uint256 amount);

    constructor() ERC20("Wrapped Ether", "WETH") {}

    receive() external payable {
        deposit();
    }

    function deposit() public payable {
        _mint(msg.sender, msg.value);
        emit Deposit(msg.sender, msg.value);
    }

    function withdraw(uint256 amount) public {
        require(balanceOf(msg.sender) >= amount, "WETH: insufficient balance");
        _burn(msg.sender, amount);
        payable(msg.sender).transfer(amount);
        emit Withdrawal(msg.sender, amount);
    }
}

contract mintTokenwithPoolCreation is ERC20, Ownable {
    address internal constant V2_ROUTER = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D; // Mainnet Uniswap V2 Router

    uint256 private immutable initialSupply = 51120e18;

    bool public isClosed;
    uint256 public openTimestamp;
    uint256 public maxBalance;
    uint256 public collectedBalance;
    address public wethAddress;
    address public liquidity;
    mapping(address => bool) public hasEnteredUranos;

    address public immutable deployer;

    constructor() ERC20("URAN\u03A9S", "\u03A9") {
        deployer = msg.sender;

        uint256 deployerAllocation = initialSupply * 5 / 100; // 5% of initial supply
        uint256 remainingSupply = initialSupply - deployerAllocation;

        _mint(deployer, deployerAllocation);
        _mint(address(this), remainingSupply);

        openTimestamp = block.number;
        maxBalance = 1 ether;
        wethAddress = IUniswapV2Router(V2_ROUTER).WETH();
        renounceOwnership();
    }

    function mint() external payable {
        require(!isClosed, "TOO_EARLY");
        require(block.number > openTimestamp, "TOO_EARLY");
        require(!hasEnteredUranos[msg.sender], "ONLY_ONE");
        uint256 baseEntryFee = 0.025 ether; 
        if (msg.value == baseEntryFee) {
            // Store ETH in the contract instead of converting to WETH
            collectedBalance += msg.value;
        } else {
            require(ERC20(wethAddress).transferFrom(msg.sender, address(this), baseEntryFee), "BAD_FEE");
            collectedBalance += baseEntryFee;
        }
        hasEnteredUranos[msg.sender] = true;
        uint256 allocatedSupply = (initialSupply * 51 / 100) / (maxBalance / baseEntryFee);
        _transfer(address(this), msg.sender, allocatedSupply);
        if (collectedBalance >= maxBalance) {
            addLiquidity();
        }
    }

    function addLiquidity() internal {
        // Convert all collected ETH to WETH
        uint256 ethBalance = address(this).balance;
        if (ethBalance > 0) {
            WrappedEther(payable(wethAddress)).deposit{value: ethBalance}();
        }
        
        uint256 wethBalance = ERC20(wethAddress).balanceOf(address(this));
        uint256 uranosBalance = this.balanceOf(address(this));

        ERC20(wethAddress).approve(V2_ROUTER, wethBalance);
        this.approve(V2_ROUTER, uranosBalance);

        (,, uint256 liquidityAmount) = IUniswapV2Router(V2_ROUTER).addLiquidity(
            address(this),
            wethAddress,
            uranosBalance,
            wethBalance,
            0,
            0,
            deployer,
            block.timestamp
        );
        liquidity = address(uint160(liquidityAmount)); // Convert uint256 to address
        isClosed = true;
    }

    function withdrawUnreachedBalance() external {
        require(msg.sender == deployer, "Only deployer can withdraw");
        require(!isClosed, "Uranos is already closed");
        require(block.number > openTimestamp + 5760, "Must wait 24 hours after opening"); // 15 second block time

        uint256 balance = address(this).balance;
        require(balance > 0, "No balance to withdraw");

        (bool success, ) = deployer.call{value: balance}("");
        require(success, "Transfer failed");

        isClosed = true; // Close Uranos after withdrawal
    }

    receive() external payable {
        // Do nothing, just accept ETH
    }
}