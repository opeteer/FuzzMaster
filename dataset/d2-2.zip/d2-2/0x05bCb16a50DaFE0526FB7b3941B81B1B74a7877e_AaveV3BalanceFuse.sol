// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.26;

import {SafeCast} from "@openzeppelin/contracts/utils/math/SafeCast.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Errors} from "../../libraries/errors/Errors.sol";
import {IMarketBalanceFuse} from "../IMarketBalanceFuse.sol";
import {IAavePriceOracle} from "./ext/IAavePriceOracle.sol";
import {IAavePoolDataProvider} from "./ext/IAavePoolDataProvider.sol";
import {IporMath} from "../../libraries/math/IporMath.sol";
import {Errors} from "../../libraries/errors/Errors.sol";
import {PlasmaVaultConfigLib} from "../../libraries/PlasmaVaultConfigLib.sol";

/// @title Fuse for Aave V3 protocol responsible for calculating the balance of the Plasma Vault in Aaave V3 protocol based on preconfigured market substrates
/// @dev Substrates in this fuse are the assets that are used in the Aave V3 protocol for a given MARKET_ID
contract AaveV3BalanceFuse is IMarketBalanceFuse {
    using SafeCast for int256;

    /// @dev Aave Price Oracle base currency decimals
    uint256 private constant AAVE_ORACLE_BASE_CURRENCY_DECIMALS = 8;

    uint256 public immutable MARKET_ID;
    address public immutable AAVE_PRICE_ORACLE;
    address public immutable AAVE_POOL_DATA_PROVIDER_V3;

    constructor(uint256 marketId_, address aavePriceOracle_, address aavePoolDataProviderV3_) {
        if (marketId_ == 0) {
            revert Errors.WrongValue();
        }
        if (aavePriceOracle_ == address(0) || aavePoolDataProviderV3_ == address(0)) {
            revert Errors.WrongAddress();
        }

        MARKET_ID = marketId_;
        AAVE_PRICE_ORACLE = aavePriceOracle_;
        AAVE_POOL_DATA_PROVIDER_V3 = aavePoolDataProviderV3_;
    }

    function balanceOf() external view override returns (uint256) {
        bytes32[] memory assetsRaw = PlasmaVaultConfigLib.getMarketSubstrates(MARKET_ID);

        uint256 len = assetsRaw.length;

        if (len == 0) {
            return 0;
        }

        int256 balanceTemp;
        int256 balanceInLoop;
        uint256 decimals;
        uint256 price; // @dev assume price represented in 8 decimals
        address asset;
        address aTokenAddress;
        address stableDebtTokenAddress;
        address variableDebtTokenAddress;
        address plasmaVault = address(this);

        for (uint256 i; i < len; ++i) {
            balanceInLoop = 0;
            asset = PlasmaVaultConfigLib.bytes32ToAddress(assetsRaw[i]);
            decimals = ERC20(asset).decimals();
            price = IAavePriceOracle(AAVE_PRICE_ORACLE).getAssetPrice(asset);

            if (price == 0) {
                revert Errors.UnsupportedQuoteCurrencyFromOracle();
            }

            (aTokenAddress, stableDebtTokenAddress, variableDebtTokenAddress) = IAavePoolDataProvider(
                AAVE_POOL_DATA_PROVIDER_V3
            ).getReserveTokensAddresses(asset);

            if (aTokenAddress != address(0)) {
                balanceInLoop += int256(ERC20(aTokenAddress).balanceOf(plasmaVault));
            }
            if (stableDebtTokenAddress != address(0)) {
                balanceInLoop -= int256(ERC20(stableDebtTokenAddress).balanceOf(plasmaVault));
            }
            if (variableDebtTokenAddress != address(0)) {
                balanceInLoop -= int256(ERC20(variableDebtTokenAddress).balanceOf(plasmaVault));
            }

            balanceTemp += IporMath.convertToWadInt(
                balanceInLoop * int256(price),
                decimals + AAVE_ORACLE_BASE_CURRENCY_DECIMALS
            );
        }

        return balanceTemp.toUint256();
    }
}