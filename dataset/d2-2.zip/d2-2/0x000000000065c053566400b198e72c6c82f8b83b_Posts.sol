/**
 *Submitted for verification at Etherscan.io on 2024-09-16
*/

// SPDX-License-Identifier: AGPL-3.0-only
pragma solidity ^0.8.19;

interface IERC1155 {
    function balanceOf(address, uint256) external view returns (uint256);
}

/// @notice Onchain posting singleton for ERC1155/ERC6909 token holders.
contract Posts {
    struct Post {
        uint96 datedTo;
        address poster;
        string message;
        Call execution;
        uint256 agreed;
    }

    struct Call {
        address target;
        uint256 ethers;
        bytes callData;
    }

    mapping(IERC1155 token => mapping(uint256 id => Post[])) internal posts;
    mapping(
        address user
            => mapping(IERC1155 token => mapping(uint256 id => mapping(uint256 index => uint256)))
    ) public cast;

    error Unauthorized();
    error InvalidIndex();
    error AlreadyCast();
    error Uncast();

    event Posted(IERC1155 indexed token, uint256 indexed id, uint256 indexed index);
    event Agreed(
        IERC1155 indexed token,
        uint256 indexed id,
        uint256 index,
        address indexed user,
        uint256 balance
    );

    function post(IERC1155 token, uint256 id, string calldata message, Call calldata call)
        public
        returns (uint256 index)
    {
        if (token.balanceOf(msg.sender, id) == 0) revert Unauthorized();
        posts[token][id].push(
            Post({
                datedTo: uint96(block.timestamp),
                poster: msg.sender,
                message: message,
                execution: call,
                agreed: 0
            })
        );
        unchecked {
            index = posts[token][id].length - 1;
            emit Posted(token, id, index);
        }
    }

    function agree(IERC1155 token, uint256 id, uint256 index) public {
        if (index >= posts[token][id].length) revert InvalidIndex();
        uint256 balance = token.balanceOf(msg.sender, id);
        if (balance == 0) revert Unauthorized();
        if (cast[msg.sender][token][id][index] != 0) revert AlreadyCast();
        unchecked {
            // We assume token is trusted.
            posts[token][id][index].agreed += balance;
            cast[msg.sender][token][id][index] = balance;
        }
        emit Agreed(token, id, index, msg.sender, balance);
    }

    function disagree(IERC1155 token, uint256 id, uint256 index) public {
        if (index >= posts[token][id].length) revert InvalidIndex();
        uint256 balance = token.balanceOf(msg.sender, id);
        if (balance == 0) revert Unauthorized();
        uint256 _cast = cast[msg.sender][token][id][index];
        if (_cast == 0) revert Uncast();
        unchecked {
            posts[token][id][index].agreed -= _cast;
            delete cast[msg.sender][token][id][index];
        }
        emit Agreed(token, id, index, msg.sender, 0);
    }

    function getPost(IERC1155 token, uint256 id, uint256 index) public view returns (Post memory) {
        return posts[token][id][index];
    }

    function getPosts(IERC1155 token, uint256 id) public view returns (Post[] memory) {
        return posts[token][id];
    }

    function getLastPosts(IERC1155 token, uint256 id, uint256 count)
        public
        view
        returns (Post[] memory content)
    {
        uint256 len = posts[token][id].length;
        uint256 retrieveCount = count < len ? count : len;
        content = new Post[](retrieveCount);
        unchecked {
            uint256 startIndex = len - retrieveCount;
            for (uint256 i; i != retrieveCount; ++i) {
                content[i] = posts[token][id][startIndex + i];
            }
        }
    }
}