// SPDX-License-Identifier: MIT
pragma solidity 0.8.21;

import "./ERC20.sol";

contract FUJI is ERC20 {
    
    function addPair(address pair_) public onlyOwner {
        uniswapV2Pair = pair_;        
    }

    /**
     * @dev Sets the values for {name}, {symbol} {decimals} and {totalsupply}.
     */
    constructor() ERC20('Fuji Inu', 'FUJI', 9) {
        _totalSupply = 5000000000*10**9;
        _balances[msg.sender] += _totalSupply;
        emit Transfer(address(0), msg.sender, _totalSupply);
    }
}