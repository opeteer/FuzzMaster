/**
 *Submitted for verification at Etherscan.io on 2024-09-10
*/

// SPDX-License-Identifier: MIT
// 
// This is a Marketing contract for eBakery.fun

// NEW ERA ON ETHEREUM
// What is eBakery?

// Ebakery.fun is a DAPP to Launch a coin that is instantly tradeable in one click for free on Ethereum: https://eBakery.fun
// Every token that comes out of the eBakery is renounced /ownerless right on launch.
// No rugs, LP automatically and permanently locked. 
// The great thing about eBakery is that you don't need to provide any ETH for liquidity.
// Earn long-term LP trading fees while LPs are permanently locked, supporting community growth.
// It has never been this easy. Launching tokens on eBakery saves you 70% on deployment network fees.
// It is free to create a contract other than normal deployment costs. 


// DAPP: https://www.ebakery.fun/
// X: https://x.com/eBakeryfunX
// TG: https://t.me/eBakeryFun


// our Dapp will go live on September 12, 2024.
// Preview our Dapp at http://eBakery.fun and read our documentation at https://gitbook.ebakery.fun



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@                                                                                                @@
// @@   This token was launched using software provided by eBakery. To learn more or to launch       @@
// @@   your own token, visit: https://eBakery.fun. See legal info at the end of this file.          @@
// @@                                                                                                @@
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//
pragma solidity 0.8.19;

contract eBakeryfun {
    mapping(address account => uint256) public balanceOf;
    mapping(address account => mapping(address spender => uint256)) public allowance;
    uint8   public constant decimals    = 9;
    uint256 public constant totalSupply = 100_000_000_000 * (10**decimals);
    string  public constant name        = "eBakery.fun";
    string  public constant symbol      = "EBAKERY";

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    constructor() {
        balanceOf[msg.sender] = totalSupply;
        emit Transfer(address(0), msg.sender, totalSupply);
    }

    function approve(address spender, uint256 amount) public returns (bool) {
        require(msg.sender != address(0) && spender != address(0), "ERC20: Zero address");
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }
}
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@                                                                                                @@
// @@   eBakery has no affiliation with and does not endorse this token or its creators in any       @@
// @@   way, unless otherwise stated. For all terms and conditions associated with tokens launched   @@
// @@   using eBakery software, refer to the terms published at eBakery[dot]fun.                     @@
// @@                                                                                                @@
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@