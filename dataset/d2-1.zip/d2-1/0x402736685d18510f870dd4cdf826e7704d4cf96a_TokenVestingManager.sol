// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.18;

import { IERC20 } from "@openzeppelin/contracts/interfaces/IERC20.sol";
import { SafeERC20 } from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import { AccessProtected } from "./libraries/AccessProtected.sol";
import { TokenVestingLib } from "./libraries/TokenVestingLib.sol";
import { ITokenVestingManager } from "./interfaces/ITokenVestingManager.sol";

/**
 * @title Token Vesting Manager
 * @notice Contract to manage token vesting
 */
contract TokenVestingManager is AccessProtected, ITokenVestingManager {
	using TokenVestingLib for TokenVestingLib.Vesting;
	using SafeERC20 for IERC20;
	/// Address of the token to be vested
	address public immutable tokenAddress;
	/// Total number of tokens reserved for vesting
	uint256 public numTokensReservedForVesting;

	/// Holds the vesting ids for each recipient
	mapping(address => bytes32[]) public recipientVestings;
	/// Holds the vesting information for each vesting id
	mapping(bytes32 => TokenVestingLib.Vesting) public vestingById;
	/// List of all recipients
	address[] public recipients;

	/**
	 * @notice Sets the token address to be vested
	 * @param _tokenAddress - Address of the token to be vested
	 */
	constructor(address _tokenAddress) {
		if (_tokenAddress == address(0)) {
			revert TokenVestingLib.invalidAddress();
		}
		tokenAddress = _tokenAddress;
	}

	/**
	 * dev Reverts if the vesting is not active
	 */
	modifier isVestingActive(bytes32 _vestingId) {
		if (getVestingInfo(_vestingId).deactivationTimestamp != 0) {
			revert vestingNotActive();
		}
		_;
	}

	/**
	 * @notice Create a new vesting
	 * @param _recipient - Address of the recipient
	 * @param _startTimestamp - Start timestamp of the vesting
	 * @param _endTimestamp - End timestamp of the vesting
	 * @param _timelock - Timelock for the vesting
	 * @param _initialUnlock - Initial unlock amount
	 * @param _cliffReleaseTimestamp - Cliff release timestamp
	 * @param _cliffAmount - Cliff amount
	 * @param _releaseIntervalSecs - Release interval in seconds
	 * @param _linearVestAmount - Linear vest amount
	 * @return vestingId - Identifier of the vesting
	 */
	function createVesting(
		address _recipient,
		uint32 _startTimestamp,
		uint32 _endTimestamp,
		uint32 _timelock,
		uint256 _initialUnlock,
		uint32 _cliffReleaseTimestamp,
		uint256 _cliffAmount,
		uint32 _releaseIntervalSecs,
		uint256 _linearVestAmount
	) external onlyAdmin returns (bytes32 vestingId) {
		if (_recipient == address(0)) {
			revert TokenVestingLib.invalidAddress();
		}
		uint256 totalExpectedAmount = _initialUnlock +
			_cliffAmount +
			_linearVestAmount;

		numTokensReservedForVesting += totalExpectedAmount;

		vestingId = _createVesting(
			_recipient,
			_startTimestamp,
			_endTimestamp,
			_timelock,
			_initialUnlock,
			_cliffReleaseTimestamp,
			_cliffAmount,
			_releaseIntervalSecs,
			_linearVestAmount
		);
		IERC20(tokenAddress).safeTransferFrom(
			msg.sender,
			address(this),
			totalExpectedAmount
		);

		return vestingId;
	}

	/**
	 * @notice Create a batch of vestings
	 * @param params - Parameters for creating the vesting batch
	 * @return vestingIds - Identifiers of the vestings
	 */
	function createVestingBatch(
		CreateVestingBatchParams calldata params
	) external onlyAdmin returns (bytes32[] memory) {
		uint256 length = params._recipients.length;
		bytes32[] memory vestingIds = new bytes32[](length);

		uint256 totalExpectedAmount;

		{
			if (
				params._startTimestamps.length != length ||
				params._endTimestamps.length != length ||
				params._timelocks.length != length ||
				params._initialUnlocks.length != length ||
				params._cliffAmounts.length != length ||
				params._cliffReleaseTimestamps.length != length ||
				params._releaseIntervalSecs.length != length ||
				params._linearVestAmounts.length != length
			) {
				revert arrayLengthMismatch();
			}
		}

		for (uint256 i; i < params._recipients.length; ) {
			vestingIds[i] = _createVesting(
				params._recipients[i],
				params._startTimestamps[i],
				params._endTimestamps[i],
				params._timelocks[i],
				params._initialUnlocks[i],
				params._cliffReleaseTimestamps[i],
				params._cliffAmounts[i],
				params._releaseIntervalSecs[i],
				params._linearVestAmounts[i]
			);

			totalExpectedAmount +=
				uint256(params._initialUnlocks[i]) +
				uint256(params._cliffAmounts[i]) +
				params._linearVestAmounts[i];

			unchecked {
				++i;
			}
		}

		numTokensReservedForVesting += totalExpectedAmount;
		IERC20(tokenAddress).safeTransferFrom(
			msg.sender,
			address(this),
			totalExpectedAmount
		);

		return vestingIds;
	}

	/**
	 * @notice Claim vested tokens
	 * @param _vestingId - Identifier of the vesting
	 */
	function claim(bytes32 _vestingId) external {
		TokenVestingLib.Vesting storage vesting = vestingById[_vestingId];
		if (msg.sender != vesting.recipient) {
			revert notVestingOwner();
		}
		if (vesting.timelock > uint32(block.timestamp)) {
			revert TokenVestingLib.timelockEnabled();
		}

		uint256 vested = TokenVestingLib.calculateVestedAmount(
			vesting,
			uint32(block.timestamp)
		);
		uint256 claimable = vested - vesting.claimedAmount;
		if (claimable == 0) {
			revert insufficientBalance();
		}
		vesting.claimedAmount += claimable;
		numTokensReservedForVesting -= claimable;
		emit Claimed(msg.sender, claimable, _vestingId);
		IERC20(tokenAddress).safeTransfer(msg.sender, claimable);
	}

	/**
	 * @notice Revoke active Vesting
	 * @param _vestingId - Vesting Identifier
	 */
	function revokeVesting(
		bytes32 _vestingId
	) external onlyAdmin isVestingActive(_vestingId) {
		TokenVestingLib.Vesting storage vesting = vestingById[_vestingId];
		uint256 finalVestAmount = TokenVestingLib.calculateVestedAmount(
			vesting,
			vesting.endTimestamp
		);
		if (vesting.claimedAmount == finalVestAmount) {
			revert allVestedAmountAlreadyClaimed();
		}

		vesting.deactivationTimestamp = uint32(block.timestamp);
		uint256 vestedAmountNow = TokenVestingLib.calculateVestedAmount(
			vesting,
			uint32(block.timestamp)
		);

		uint256 amountRemaining = finalVestAmount - vestedAmountNow;
		numTokensReservedForVesting -= amountRemaining;

		emit VestingRevoked(vesting.recipient, amountRemaining, vesting);
	}

	/// INTERNAL FUNCTIONS

	/**
	 * @dev Internal function to create a new vesting
	 * @param _recipient - Address of the recipient
	 * @param _startTimestamp - Start timestamp of the vesting
	 * @param _endTimestamp - End timestamp of the vesting
	 * @param _timelock - Timelock for the vesting
	 * @param _initialUnlock - Initial unlock amount
	 * @param _cliffReleaseTimestamp - Cliff release timestamp
	 * @param _cliffAmount - Cliff amount
	 * @param _releaseIntervalSecs - Release interval in seconds
	 * @param _linearVestAmount - Linear vest amount
	 * @return vestingId - Identifier of the vesting
	 */
	function _createVesting(
		address _recipient,
		uint32 _startTimestamp,
		uint32 _endTimestamp,
		uint32 _timelock,
		uint256 _initialUnlock,
		uint32 _cliffReleaseTimestamp,
		uint256 _cliffAmount,
		uint32 _releaseIntervalSecs,
		uint256 _linearVestAmount
	) internal returns (bytes32) {
		if (_recipient == address(0)) {
			revert TokenVestingLib.invalidAddress();
		}
		if (_linearVestAmount + _cliffAmount == 0) {
			revert TokenVestingLib.invalidVestedAmount();
		}
		if (_startTimestamp == 0) {
			revert TokenVestingLib.invalidStartTimestamp();
		}
		if (_endTimestamp == 0) {
			revert TokenVestingLib.invalidEndTimestamp();
		}
		if (_startTimestamp > _endTimestamp) {
			revert TokenVestingLib.invalidEndTimestamp();
		}
		if (_releaseIntervalSecs == 0) {
			revert TokenVestingLib.invalidReleaseInterval();
		}
		if (_cliffReleaseTimestamp == 0) {
			if (_cliffAmount != 0) {
				revert TokenVestingLib.invalidCliffAmount();
			}
			if ((_endTimestamp - _startTimestamp) % _releaseIntervalSecs != 0) {
				revert TokenVestingLib.invalidIntervalLength();
			}
		} else {
			if (
				((_startTimestamp > _cliffReleaseTimestamp) ||
					(_cliffReleaseTimestamp >= _endTimestamp))
			) {
				revert TokenVestingLib.invalidCliffRelease();
			}
			if (_cliffAmount == 0) {
				revert TokenVestingLib.invalidCliffAmount();
			}
			if (
				(_endTimestamp - _cliffReleaseTimestamp) %
					_releaseIntervalSecs !=
				0
			) {
				revert TokenVestingLib.invalidIntervalLength();
			}
		}

		TokenVestingLib.Vesting memory vesting = TokenVestingLib.Vesting({
			recipient: _recipient,
			startTimestamp: _startTimestamp,
			endTimestamp: _endTimestamp,
			deactivationTimestamp: 0,
			timelock: _timelock,
			initialUnlock: _initialUnlock,
			cliffReleaseTimestamp: _cliffReleaseTimestamp,
			cliffAmount: _cliffAmount,
			releaseIntervalSecs: _releaseIntervalSecs,
			linearVestAmount: _linearVestAmount,
			claimedAmount: 0
		});

		bytes32 vestingId = TokenVestingLib.generateVestingId(vesting);
		if (getVestingInfo(vestingId).startTimestamp != 0) {
			revert vestingAlreadyExists(vestingId);
		}

		if (!isRecipient(_recipient)) {
			recipients.push(_recipient);
		}

		vestingById[vestingId] = vesting;
		recipientVestings[_recipient].push(vestingId);

		emit VestingCreated(_recipient, vestingId, vesting);

		return vestingId;
	}

	/// ADMIN WITHDRAW HELPER FUNCTIONS

	/**
	 * @notice Allow the owner to withdraw any balance not currently tied up in Vestings
	 * @param _amountRequested - Amount to withdraw
	 */
	function withdrawAdmin(uint256 _amountRequested) external onlyAdmin {
		uint256 amountRemaining = amountAvailableToWithdrawByAdmin();
		if (amountRemaining < _amountRequested) {
			revert insufficientBalance();
		}

		emit AdminWithdrawn(msg.sender, _amountRequested);
		IERC20(tokenAddress).safeTransfer(msg.sender, _amountRequested);
	}

	/**
	 * @notice Withdraw a token which isn't controlled by the vesting contract. Useful when someone accidentally sends tokens to the contract
	 * @param _otherTokenAddress - the token which we want to withdraw
	 */
	function withdrawOtherToken(address _otherTokenAddress) external onlyAdmin {
		if (_otherTokenAddress == tokenAddress) {
			// tokenAddress address is already sure to be nonzero due to constructor
			revert invalidToken();
		}
		uint256 balance = IERC20(_otherTokenAddress).balanceOf(address(this));
		IERC20(_otherTokenAddress).safeTransfer(msg.sender, balance);
	}

	/// @notice Amount of tokens available to withdraw by the admin
	function amountAvailableToWithdrawByAdmin() public view returns (uint256) {
		return
			IERC20(tokenAddress).balanceOf(address(this)) -
			numTokensReservedForVesting;
	}

	/**
	 * @notice Get the vesting information
	 * @param _vestingId - Identifier of the vesting
	 * @return vesting - Vesting information
	 */
	function getVestingInfo(
		bytes32 _vestingId
	) public view returns (TokenVestingLib.Vesting memory) {
		return vestingById[_vestingId];
	}

	/**
	 * @notice Get all recipients
	 * @return recipients - The list of recipients
	 */
	function getAllRecipients() external view returns (address[] memory) {
		return recipients;
	}

	/**
	 * @notice Check if a recipient has vestings
	 * @param recipient - The recipient address
	 * @return isRecipient - True if the recipient has vestings
	 */
	function isRecipient(address recipient) public view returns (bool) {
		return recipientVestings[recipient].length != 0;
	}

	/**
	 * @notice Get the length of all recipients
	 * @return length - The length of all recipients
	 */
	function getAllRecipientsLength() external view returns (uint256) {
		return recipients.length;
	}

	/**
	 * @notice Get all recipients in a range
	 * @param _from - The start index (inclusive)
	 * @param _to - The end index (exclusive)
	 * @return recipientsSliced - The list of recipients in the range
	 */
	function getAllRecipientsSliced(
		uint256 _from,
		uint256 _to
	) external view returns (address[] memory) {
		address[] memory recipientsSliced = new address[](_to - _from);
		for (uint256 i = _from; i < _to; ) {
			recipientsSliced[i - _from] = recipients[i];
			unchecked {
				++i;
			}
		}
		return recipientsSliced;
	}

	/**
	 * @notice Get all vestings for a recipient
	 * @param _recipient - The recipient address
	 * @return recipientVestings - The list of vestings for the recipient
	 */
	function getAllRecipientVestings(
		address _recipient
	) external view returns (bytes32[] memory) {
		return recipientVestings[_recipient];
	}

	/**
	 * @notice Get all vestings for a recipient in a range
	 * @param _from - The start index (inclusive)
	 * @param _to - The end index (exclusive)
	 * @param _recipient - The recipient address
	 * @return recipientVestingsSliced - The list of vestings for the recipient in the range
	 */
	function getAllRecipientVestingsSliced(
		uint256 _from,
		uint256 _to,
		address _recipient
	) external view returns (bytes32[] memory) {
		bytes32[] memory recipientVestingsSliced = new bytes32[](_to - _from);
		for (uint256 i = _from; i < _to; ) {
			recipientVestingsSliced[i - _from] = recipientVestings[_recipient][
				i
			];
			unchecked {
				++i;
			}
		}
		return recipientVestingsSliced;
	}

	/**
	 * @notice Get the length of all vestings for a recipient
	 * @param _recipient - The recipient address
	 * @return length - The length of all vestings for the recipient
	 */
	function getAllRecipientVestingsLength(
		address _recipient
	) external view returns (uint256) {
		return recipientVestings[_recipient].length;
	}
}