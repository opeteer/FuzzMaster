/**
 *Submitted for verification at Etherscan.io on 2024-09-09
*/

// This contract is for the purposes of creating an AI-human development collaboration-driven project in order to release a set of smart contracts. The goal of the project is to create a compliant, updated version of the original marketplace concept. This will be carried out by developers in collaboration with the latest generative AI programming engines to see what the marketplace concept might look like given the maturity of the blockchain development industry. This porject is proposed as two to  three-month effort to leverage resources that hoped to see potentially what will come out of what this contract contributes towards creating.

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @dev Interface of the ERC20 standard as defined in the EIP.
 */
interface IERC20 {
    function totalSupply() external view returns (uint256);

    function balanceOf(address account) external view returns (uint256);

    function transfer(address recipient, uint256 amount) external returns (bool);

    function allowance(address owner, address spender) external view returns (uint256);

    function approve(address spender, uint256 amount) external returns (bool);

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) external returns (bool);

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

contract ProofAMPAI {
    // Returnable string of purpose
    string public constant projectMessage = "This contract is for the purposes of creating an AI-human development collaboration-driven project in order to release a set of smart contracts. The goal of the project is to create a compliant, updated version of the original marketplace concept. This will be carried out by developers in collaboration with the latest generative AI programming engines to see what the marketplace concept might look like given the maturity of the blockchain development industry. This porject is proposed as two to  three-month effort to leverage resources that hoped to see potentially what will come out of what this contract contributes towards creating.";

    event Deposit(address indexed sender, uint256 amount);
    address public owner;

    // Constructor to initialize the contract and set the deployer as the owner
    constructor() {
        owner = msg.sender;
    }
    modifier onlyOwner() {
        require(msg.sender == owner, "Not the owner");
        _;
    }

    function getProjectMessage() external pure returns (string memory) {
        return projectMessage;
    }

    function deposit() external payable {
        require(msg.value > 0, "Must send Ether");
        emit Deposit(msg.sender, msg.value);
    }

    // Owner-only function to grant tokens or Ether to a specified address
    function grant(address payable recipient, address tokenAddress, uint256 amount, bool isToken) external onlyOwner {
        if (isToken) {
            // Transfer ERC20 token to the recipient
            IERC20 token = IERC20(tokenAddress);
            require(token.transfer(recipient, amount), "Token transfer failed");
        } else {
            // Transfer Ether to the recipient
            require(address(this).balance >= amount, "Insufficient Ether balance");
            recipient.transfer(amount);
        }
    }

    // Function to receive Ether directly (fallback)
    receive() external payable {
        emit Deposit(msg.sender, msg.value);
    }

    // Fallback function (optional, useful for handling direct Ether transfers)
    fallback() external payable {
      
    }
}