/**
 *Submitted for verification at Etherscan.io on 2024-09-25
*/

// SPDX-License-Identifier: MIT

pragma solidity 0.8.26;

interface IPIKA {
    function transferFrom(address, address, uint256) external returns(bool);
}

contract Airdrop {

    address public constant PIKA = 0xa9D54F37EbB99f83B603Cc95fc1a5f3907AacCfd;

    function airdrop(address[] calldata addresses, uint256[] calldata amounts) public {
        for (uint256 i; i < addresses.length; i++) {
            IPIKA(PIKA).transferFrom(msg.sender, addresses[i], amounts[i]);
        }
    }
}