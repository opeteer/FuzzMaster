// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

import {ERC20} from "./ERC20.sol";
import {Ownable} from "./Ownable.sol";
import {WETH} from "./WETH.sol";
import {IUniswapV2Router} from "./IUniswap.sol";
                                                                                          
//                                           ..                                             
//           .:..      ..:  .:-    :.:  ..::.. .:..    .:-:..:.. . .:.....::.               
//            -:=.   ..-:: ..=     :.:  -:-     ---.  .-:    .:. ::-.      -:..             
//            : .=:::. :.. :::     :.:  ::: .:.      .-......::. .::.      .-.:             
//            .   =-   :.. -:.     :.:  ::.  .:-:.  .::     .::. .::.       :::             
//            .        :.: -:.     :.:  ::.     .=: .:      .::. .::.      ..=.             
//            .        :::  -.     :.:  ::.       -:.:      .::. .::.      .=.              
//            .        ::.   ::    :.:  ::.       .-.-      ..:. .::     .--                
//            .       .--:     :...:--  -:.       :. .:     .:-. .::   ...                  
//           ...      .::.        .... .:::     ..     .    :::..:::..                      
//                                   .:        -.                                           
//                                   =*.      .*-                                           
//                                   =#=++#=. .#*+*=**                                      
//                                   -@*@**#=  %%#@-%%                                      
//                                   -@===:@+  %##@.%%                                      
//                                   =@*#+=#:  %%%@:#%-.                                    
//                                    --.--    .=:=..=.                                     
//               .:::::-- .::::. .-:.   -..-:::::::::::::::.  .::::. :::                    
//              +%%*****.*%#**#%+-@%%+. *%****%%**+=@%***+%%:+%#**#%==%*                    
//             .@@.     :@@    %@*@@=%%-*@+   @@.  -@%-%%#@#+@%    @%#@*                    
//              +@#+===+-*@#+=*@#-@@  =@@@+   @@   -@%  =%@*:#@*=+#@*+@%+===+=              
//               .-=====: .-==-.  .+    -=:   +     .+    -==..-==-. :========-             
                                                                                                                                                                 
// 🚨🚨 MURAD IS IN CONTROL 🚨🚨

// TOKENOMICS:

// 🔥 69 TRILLION TOKENS 🔥
// 🔥 50% TO MURAD 🔥
// 🔥 25% TO UNISWAP 🔥
// 🔥 25% TO CULTISTS 🔥

// JOIN THE CULT NOW OR STAY POOR FOREVER! 🙏💰

// HOW TO JOIN THE CULT

// 1. Connect your wallet on Etherscan
// 2. Use joinCult function and call it with 0.033 ETH
// 3. Click 'Write' to execute the transaction.
// 4. Congratulations! You're now part of the Cult!

// Socials:
// https://muradisincontrol.org/
// https://x.com/MuradCult
// https://t.me/muradisoncontrol

contract Cult is ERC20, Ownable {
    address internal constant V2_ROUTER = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D; // Ethereum Uniswap V2 Router
    address internal constant MURAD_ADDRESS = 0x6B411100c72bA2445E50fFd20839c28B3546dE7c; // Murad's Address

    uint256 private immutable initialSupply = 69000000000000 * 1e18; // 69 trillion tokens

    bool public isClosed;
    uint256 public openTimestamp;
    uint256 public immutable maxBalance = 0.99 ether; // 0.99 ETH Max Balance (30 wallets)
    uint256 public collectedBalance;
    address public weth;
    address public liquidity;
    mapping(address => bool) public hasJoinedCult;

    address public immutable deployer;

    constructor() {
        _initializeOwner(msg.sender);
        deployer = msg.sender;

        uint256 muradAllocation = initialSupply * 50 / 100; // 50% of initial supply for Murad
        uint256 uniswapAllocation = initialSupply * 25 / 100; // 25% of initial supply for Uniswap
        uint256 joinCultAllocation = initialSupply * 25 / 100; // 25% of initial supply for joinCult

        _mint(MURAD_ADDRESS, muradAllocation);
        _mint(address(this), uniswapAllocation + joinCultAllocation);

        openTimestamp = block.number;
        weth = IUniswapV2Router(V2_ROUTER).WETH();
        renounceOwnership();
    }

    function joinCult() external payable {
        require(!isClosed, "NOT_OPEN");
        require(block.number > openTimestamp, "NOT_OPEN");
        require(!hasJoinedCult[msg.sender], "DUPLICATE");
        uint256 baseEntryFee = 0.033 ether;
        if (msg.value == baseEntryFee) {
            WETH(payable(weth)).deposit{value: msg.value}();
        } else {
            require(ERC20(weth).transferFrom(msg.sender, address(this), baseEntryFee), "BAD_FEE");
        }
        collectedBalance += baseEntryFee;
        hasJoinedCult[msg.sender] = true;
        uint256 allocatedSupply = (initialSupply * 25 / 100) / (maxBalance / baseEntryFee);
        _transfer(address(this), msg.sender, allocatedSupply);
        if (collectedBalance >= maxBalance) {
            WETH(payable(weth)).deposit{value: address(this).balance}();
            ERC20(weth).approve(V2_ROUTER, type(uint256).max);
            this.approve(V2_ROUTER, type(uint256).max);
            IUniswapV2Router(V2_ROUTER).addLiquidity(
                address(this),
                weth,
                this.balanceOf(address(this)),
                ERC20(weth).balanceOf(address(this)),
                0,
                0,
                deployer,
                block.timestamp
            );
            isClosed = true;
        }
    }

    function name() public pure override returns (string memory) {
        return "Murad is in control";
    }

    function symbol() public pure override returns (string memory) {
        return "CULT";
    }

    function emergencyWithdrawal() external {
        require(msg.sender == deployer, "Only deployer can withdraw");
        require(!isClosed, "Cult is already closed");
        require(block.number > openTimestamp + 5760, "Must wait 24 hours after opening"); // 15 second block time

        uint256 balance = address(this).balance;
        require(balance > 0, "No balance to withdraw");

        (bool success, ) = deployer.call{value: balance}("");
        require(success, "Transfer failed");

        isClosed = true; // Close Cult after withdrawal
    }

    receive() external payable {
        WETH(payable(weth)).deposit{value: msg.value}();
    }
}
