// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.24;

import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC721/extensions/ERC721EnumerableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC721/extensions/ERC721URIStorageUpgradeable.sol";
import "./library/Initialization.sol";
import "hardhat/console.sol";

contract TreasureWalletHunt721 is
    OwnableUpgradeable,
    AccessControlUpgradeable,
    PausableUpgradeable,
    ERC721EnumerableUpgradeable,
    ERC721URIStorageUpgradeable
{

    uint256 public maxSupply;
    bool public isPublicMint;
    uint256 public mintPrice;
    string public baseURI;

    constructor(Initialization.Initialization721 memory init) {
        initialize(init);
    }

    function initialize(Initialization.Initialization721 memory init)
        public
        initializer
    {
        __Ownable_init(msg.sender);
        __Pausable_init();

        __ERC721_init(init.name, init.symbol);
        
        for (uint256 i = 0; i < init.admins.length; i++) {
            _grantRole(DEFAULT_ADMIN_ROLE, init.admins[i]);
        }

        maxSupply = init.maxSupply;
        isPublicMint = init.isPublicMint;
        mintPrice = init.mintPrice;
    }

    function setBaseURI(string memory uri)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
        whenNotPaused
    {
        baseURI = uri;
    }

    function _baseURI() internal view override returns (string memory) {
        return baseURI;
    }

    function publicMint(address receiver) external payable {
        console.log("I FINALLY RUN %o", isPublicMint);

        require(isPublicMint, "PM1");
        require(msg.value >= mintPrice, "PM2");
        _mintTo(receiver);
    }

    //may make a new role as this should probably only ever be allowed to be called succesfully
    //by one multi-sig or ledger.
    //at time of withdrawel, if curios fees are turned on, then send some % to curios, rest to wallet address.
    //Otherwise all to wallet address
    function withdrawPublicMintFunds(address wallet)
        external
        payable
        onlyRole(DEFAULT_ADMIN_ROLE)
        whenNotPaused
    {
        (bool sent, ) = wallet.call{value: address(this).balance}("");
        require(sent, "Failed to send Ether");
    }

    function mint() external {
        mintTo(msg.sender);
    }

    function mintAndSetURI (address addr, string memory tokenURL ) public onlyRole(DEFAULT_ADMIN_ROLE) {
        _mintToSetUri(addr, tokenURL);
    }

    function mintTo(address addr) public onlyRole(DEFAULT_ADMIN_ROLE) {
        _mintTo(addr);
    }

    function _mintTo(address addr) internal whenNotPaused {
        if (maxSupply == 0) {
            _safeMint(addr, totalSupply(), "");
        } else {
            require(totalSupply() < maxSupply, "M1");
            _safeMint(addr, totalSupply(), "");
        }
    }

    function _mintToSetUri(address addr, string memory tokenURL) internal whenNotPaused {
        uint256 newItemId = totalSupply();
        if (maxSupply == 0) {
            _safeMint(addr, newItemId, "");
            _setTokenURI(newItemId, tokenURL);
        } else {
            require(newItemId < maxSupply, "M1");
            _safeMint(addr, newItemId, "");
            _setTokenURI(newItemId, tokenURL);
        }
    }

    function burn(uint256 tokenId)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
        whenNotPaused
    {
        _burn(tokenId);
    }

    function tokenURI(uint256 tokenId)
        public
        view
        override(ERC721Upgradeable, ERC721URIStorageUpgradeable)
        returns (string memory)
    {
        return ERC721URIStorageUpgradeable.tokenURI(tokenId);
    }

    function pause() external onlyRole(DEFAULT_ADMIN_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) {
        _unpause();
    }

        function _increaseBalance(address account, uint128 value) internal override(ERC721Upgradeable, ERC721EnumerableUpgradeable) {
        super._increaseBalance(account, value);
    }

    // Other necessary overrides

    function _update(address to, uint256 tokenId, address auth) 
        internal 
        override(ERC721Upgradeable, ERC721EnumerableUpgradeable) 
        returns (address)
    {
        return super._update(to, tokenId, auth);
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(AccessControlUpgradeable, ERC721EnumerableUpgradeable, ERC721URIStorageUpgradeable)
        returns (bool)
    {
        return super.supportsInterface(interfaceId);
    }

    function setPublicMint(bool _isPublicMint) public onlyRole(DEFAULT_ADMIN_ROLE) {
        isPublicMint = _isPublicMint;
    }

}