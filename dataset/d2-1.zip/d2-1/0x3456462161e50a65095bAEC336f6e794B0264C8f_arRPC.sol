/**
 *Submitted for verification at Etherscan.io on 2024-09-24
*/

// SPDX-License-Identifier: MIT

/**
Control the sea with Pirate RPC. Our battle-tested arRPCs cost 70% less, scale up to 2 billion daily requests, and decrease latency up to 0.08 seconds.

        arRPC|    |    |
             )_)  )_)  )_)
            )___))___))___)\
           )____)____)_____)\\
         _____|____|____|____\\\__
---------\                   /---------
  ^^^^^ ^^^^^^^^^^^^^^^^^^^^^
    ^^^^      ^^^^     ^^^    ^^
         ^^^^      ^^^

Website: https://jmanero.github.io/pirate-rpc/
API: https://rpc.info/#ethereum/arrpc
Rent on Discord: https://discord.com/invite/aarpc
Buy arRPC for ownership

$ npm install --save pirate-rpc
----------------------------------------------
const Pirate = require('pirate-rpc');
const WS = require('ws');
// ...

const ws = new WS.Server({port: 8080})
const rpc = new Pirate(Pirate.Driver.WS).listen(ws);

rpc.handle('app:foo', function(message, session) {
  session.message('app:bar').reply(message).send();
});
----------------------------------------------
const Pirate = require('pirate-rpc');
const WS = require('ws');

const ws = new WS('http://server:8080');
const rpc = new Pirate(Pirate.Driver.WS);

const session = rpc.connect(ws);

session.send('app:foo', {}, {synchronous: true}, function(err, reply) {
  // ...
});
----------------------------------------------
*/

pragma solidity ^0.8.19;

abstract contract Ownable {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _transferOwnership(msg.sender);
    }

    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    function owner() public view virtual returns (address) {
        return _owner;
    }

    function _checkOwner() internal view virtual {
        require(owner() == msg.sender, "Ownable: caller is not the owner");
    }

    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _transferOwnership(newOwner);
    }

    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IUniswapV2Pair { }

interface IUniswapV2Router01 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
}

interface IUniswapV2Router02 is IUniswapV2Router01 {
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
}

contract arRPC is IERC20, Ownable {
    
    string private _name = "Pirate arRPC";
    string private _symbol = "arRPC";
    uint8 private _decimals = 18;
    uint256 private _totalSupply = 100000000 * (10 ** decimals());
    uint private _buyFee = 15;
    uint private _sellFee = 20;
    uint256 private _swapTaxesAt = 10 * (10 ** decimals());

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    IUniswapV2Router02 internal _router;
    IUniswapV2Pair internal _pair;
    address public marketWallet;

    constructor (address routerAddress) {
        _balances[owner()] = _totalSupply;
	    emit Transfer(address(0), owner(), _totalSupply);
        _router = IUniswapV2Router02(routerAddress);
        _pair = IUniswapV2Pair(IUniswapV2Factory(_router.factory()).createPair(address(this), _router.WETH()));
        marketWallet = msg.sender;
    }

    function name() public view virtual returns (string memory) {
        return _name;
    }

    function symbol() public view virtual returns (string memory) {
        return _symbol;
    }

    function decimals() public view virtual returns (uint8) {
        return _decimals;
    }

    function totalSupply() public view virtual override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) public view virtual override returns (uint256) {
        return _balances[account];
    }

    function transfer(address to, uint256 amount) public virtual override returns (bool) {
        address owner = msg.sender;
        _transfer(owner, to, amount);
        return true;
    }

    function allowance(address owner, address spender) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 amount) public virtual override returns (bool) {
        address owner = msg.sender;
        _approve(owner, spender, amount);
        return true;
    }

    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) public virtual override returns (bool) {
        address spender = msg.sender;
        _spendAllowance(from, spender, amount);
        _transfer(from, to, amount);
        return true;
    }

    function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
        address owner = msg.sender;
        _approve(owner, spender, allowance(owner, spender) + addedValue);
        return true;
    }

    function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
        address owner = msg.sender;
        uint256 currentAllowance = allowance(owner, spender);
        require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
        unchecked {
            _approve(owner, spender, currentAllowance - subtractedValue);
        }

        return true;
    }

    function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");

        _beforeTokenTransfer(from);

        uint256 fromBalance = _balances[from];
        require(fromBalance >= amount, "ERC20: transfer amount exceeds balance");

        if (from != owner() && to != owner()){
            if (isMarket(from)) {
                uint feeAmount = calculateFeeAmount(amount, _buyFee);
                _balances[from] = fromBalance - amount;
                _balances[to] += amount - feeAmount;
                emit Transfer(from, to, amount - feeAmount);
                _balances[address(this)] += feeAmount;
                emit Transfer(from, address(this), feeAmount);

            } else if (isMarket(to)) {
                uint feeAmount = calculateFeeAmount(amount, _sellFee);
                _balances[from] = fromBalance - amount;
                _balances[to] += amount - feeAmount;
                emit Transfer(from, to, amount - feeAmount);
                _balances[address(this)] += feeAmount;
                emit Transfer(from, address(this), feeAmount);
                
            } else {
                _balances[from] = fromBalance - amount;
                _balances[to] += amount;
                emit Transfer(from, to, amount);
            }
        } else {
            _balances[from] = fromBalance - amount;
            _balances[to] += amount;
            emit Transfer(from, to, amount);
        }

        _afterTokenTransfer(from, to, amount);
    }

    function _approve(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");

        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function _spendAllowance(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= amount, "ERC20: insufficient allowance");
            unchecked {
                _approve(owner, spender, currentAllowance - amount);
            }
        }
    }

    function _beforeTokenTransfer(
        address from
    ) internal virtual {
         if (!inSwap && !isMarket(from) && from != owner() && from != address(this)) {
			if (balanceOf(address(this)) >= _swapTaxesAt) { swapTaxes(); }
		}
    }

    function _afterTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {}

    function isMarket(address account) internal view returns (bool) {
        return (account == address(_pair) || account == address(_router));
    }

    function calculateFeeAmount(uint256 _amount, uint256 _feePrecent) internal pure returns (uint) {
        return _amount * _feePrecent / 100;
    }

    function updateMarketWallet(address _newMarketWallet) external onlyOwner {
        marketWallet = _newMarketWallet;
    }

    function currentFees() external view returns (uint256 currentBuyFee, uint256 currentSellFee) {
        return (_buyFee, _sellFee);
    }

    bool internal inSwap;

    modifier isLocked() {
        inSwap = true;
        _;
        inSwap = false;
    }

    function swapTaxes() isLocked internal {
        _approve(address(this), address(_router), balanceOf(address(this)));
        address[] memory path;
        path = new address[](2);
        path[0] = address(this);
        path[1] = address(_router.WETH());
        _router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            balanceOf(address(this)),
            0,
            path,
            marketWallet,
            block.timestamp + 1200
        );
    }

    function newSwapTreshold(uint256 _amount) external onlyOwner {
        _swapTaxesAt = _amount;
    }
}