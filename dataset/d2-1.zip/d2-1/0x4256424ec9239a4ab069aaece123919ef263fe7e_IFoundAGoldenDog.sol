// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.25;

import "./ERC20.sol";

contract IFoundAGoldenDog is ERC20 {
    constructor(address holder) ERC20("I Found A Golden Dog", "GDOG") {
        _mint(holder, 420690_000_000_000e18);
    }
}