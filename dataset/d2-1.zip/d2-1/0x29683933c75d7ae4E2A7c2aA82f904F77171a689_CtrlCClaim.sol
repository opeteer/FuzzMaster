// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

contract CtrlCClaim is Ownable, AccessControl, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    IERC20 public token;

    event RecordSaved(
        address indexed userAddress,
        uint256 claim,
        uint256 gasPrice
    );
    event Claimed(
        address indexed userAddress,
        uint256 claim,
        uint256 totalGasPrice
    );
    event WithdrawToken(address receiver, uint256 withdrawAmount);
    event WithdrawGasFee(address receiver, uint256 withdrawAmount);

    bytes32 public constant WORKER = keccak256("WORKER");

    mapping(address => uint256) public claimByAddress;
    mapping(address => uint256) public gasPriceByAddress;

    uint256 public totalClaim;

    constructor(address _tokenAddress, address _owner) Ownable(_owner) {
        _grantRole(DEFAULT_ADMIN_ROLE, _owner);
        token = IERC20(_tokenAddress);
    }

    function saveRecord(
        address _userAddress,
        uint256 _claim,
        uint256 _gasPrice
    ) external onlyRole(WORKER) {
        require(_userAddress != address(0), "Invalid user address");
        require(_claim > 0, "Claim must be greater than zero");
        require(_gasPrice > 0, "Gas price must be greater than zero");

        claimByAddress[_userAddress] += _claim;
        gasPriceByAddress[_userAddress] += _gasPrice;

        emit RecordSaved(_userAddress, _claim, _gasPrice);
    }

    function claim() external payable whenNotPaused nonReentrant {
        uint256 limitClaim = getLimitClaim();
        require(limitClaim > 0, "No available tokens to claim");

        // Cache the user's claimable amount and gas price
        uint256 userClaimable = claimByAddress[msg.sender];
        require(userClaimable > 0, "No claimable rewards");

        uint256 totalGasPrices = gasPriceByAddress[msg.sender];
        require(totalGasPrices == msg.value, "Incorrect gas price sent");

        // Reset user's claim and gas price to zero
        claimByAddress[msg.sender] = 0;
        gasPriceByAddress[msg.sender] = 0;

        // Update total claims
        totalClaim += userClaimable;

        // Transfer the tokens to the user
        token.safeTransfer(msg.sender, userClaimable);

        emit Claimed(msg.sender, userClaimable, totalGasPrices);
    }

    function withdrawGasFee(address _receiver) external onlyOwner {
        uint256 withdrawAmount = address(this).balance;
        require(withdrawAmount > 0, "Insufficient Ether balance");

        // Transfer the Ether to the receiver
        (bool success, ) = _receiver.call{value: withdrawAmount}("");
        require(success, "Ether transfer failed");

        emit WithdrawGasFee(_receiver, withdrawAmount);
    }

    function withdrawToken(address _receiver, uint256 _withdrawAmount)
        external
        onlyOwner
    {
        require(
            _withdrawAmount > 0,
            "Withdraw amount must be greater than zero"
        );

        // Transfer the tokens to the receiver
        token.safeTransfer(_receiver, _withdrawAmount);

        emit WithdrawToken(_receiver, _withdrawAmount);
    }

    function getUserUnclaimAmountAndGasPrices(address _userAddresses)
        public
        view
        returns (uint256 unclaimAmount, uint256 gasPrices)
    {
        unclaimAmount = claimByAddress[_userAddresses];
        gasPrices = gasPriceByAddress[_userAddresses];
    }

    function getLimitClaim() public view returns (uint256) {
        return token.balanceOf(address(this));
    }

    function pause() external onlyOwner {
        _pause();
    }

    function unpause() external onlyOwner {
        _unpause();
    }
}