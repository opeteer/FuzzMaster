/**
 *Submitted for verification at Etherscan.io on 2024-09-18
*/

// SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

interface IAbuyToken {
    function multiBuy(address tokenAddress, uint256 exactTokensNumbers) external payable;
}

contract CallerContract {
    address public owner;
    IAbuyToken public abuyTokenContract;
    address private _abuyTokenAddress = 0x7E97f22a9C6B95D7a4DCa1D3A2a077aC791a96eB;
    constructor() {
        owner = msg.sender;
        abuyTokenContract = IAbuyToken(_abuyTokenAddress);
    }

    function multiBuy(address tokenAddress, uint256 exactTokensNumbers) external payable {
        
        abuyTokenContract.multiBuy{value: msg.value}(tokenAddress, exactTokensNumbers);
    }


    receive() external payable {}
}