/**
 *Submitted for verification at Etherscan.io on 2024-09-27
*/

// SPDX-License-Identifier: MIT

pragma solidity 0.8.24;

// Sources flattened with hardhat v2.12.6 https://hardhat.org

// File @openzeppelin/contracts/utils/[email protected]

// OpenZeppelin Contracts v4.4.1 (utils/Context.sol)

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

// File @openzeppelin/contracts/access/[email protected]

// OpenZeppelin Contracts (last updated v4.7.0) (access/Ownable.sol)

/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * By default, the owner account will be the one that deploys the contract. This
 * can later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
abstract contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(
        address indexed previousOwner,
        address indexed newOwner
    );

    /**
     * @dev Initializes the contract setting the deployer as the initial owner.
     */
    constructor() {
        _transferOwnership(_msgSender());
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if the sender is not the owner.
     */
    function _checkOwner() internal view virtual {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions anymore. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby removing any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(
            newOwner != address(0),
            "Ownable: new owner is the zero address"
        );
        _transferOwnership(newOwner);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

// File @openzeppelin/contracts/token/ERC20/[email protected]

// OpenZeppelin Contracts (last updated v4.6.0) (token/ERC20/IERC20.sol)

/**
 * @dev Interface of the ERC20 standard as defined in the EIP.
 */
interface IERC20 {
    /**
     * @dev Emitted when `value` tokens are moved from one account (`from`) to
     * another (`to`).
     *
     * Note that `value` may be zero.
     */
    event Transfer(address indexed from, address indexed to, uint256 value);

    /**
     * @dev Emitted when the allowance of a `spender` for an `owner` is set by
     * a call to {approve}. `value` is the new allowance.
     */
    event Approval(
        address indexed owner,
        address indexed spender,
        uint256 value
    );

    /**
     * @dev Returns the amount of tokens in existence.
     */
    function totalSupply() external view returns (uint256);

    /**
     * @dev Returns the amount of tokens owned by `account`.
     */
    function balanceOf(address account) external view returns (uint256);

    /**
     * @dev Moves `amount` tokens from the caller's account to `to`.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transfer(address to, uint256 amount) external returns (bool);

    /**
     * @dev Returns the remaining number of tokens that `spender` will be
     * allowed to spend on behalf of `owner` through {transferFrom}. This is
     * zero by default.
     *
     * This value changes when {approve} or {transferFrom} are called.
     */
    function allowance(
        address owner,
        address spender
    ) external view returns (uint256);

    /**
     * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * IMPORTANT: Beware that changing an allowance with this method brings the risk
     * that someone may use both the old and the new allowance by unfortunate
     * transaction ordering. One possible solution to mitigate this race
     * condition is to first reduce the spender's allowance to 0 and set the
     * desired value afterwards:
     * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729
     *
     * Emits an {Approval} event.
     */
    function approve(address spender, uint256 amount) external returns (bool);

    /**
     * @dev Moves `amount` tokens from `from` to `to` using the
     * allowance mechanism. `amount` is then deducted from the caller's
     * allowance.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) external returns (bool);
}

library Address {

    function isContract(address account) internal view returns (bool) {
        // This method relies on extcodesize/address.code.length, which returns 0
        // for contracts in construction, since the code is only stored at the end
        // of the constructor execution.

        return account.code.length > 0;
    }

    function sendValue(address payable recipient, uint256 amount) internal {
        require(address(this).balance >= amount, "Address: insufficient balance");

        (bool success, ) = recipient.call{value: amount}("");
        require(success, "Address: unable to send value, recipient may have reverted");
    }

    function functionCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, "Address: low-level call failed");
    }

    function functionCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, errorMessage);
    }

    function functionCallWithValue(
        address target,
        bytes memory data,
        uint256 value
    ) internal returns (bytes memory) {
        return functionCallWithValue(target, data, value, "Address: low-level call with value failed");
    }

    function functionCallWithValue(
        address target,
        bytes memory data,
        uint256 value,
        string memory errorMessage
    ) internal returns (bytes memory) {
        require(address(this).balance >= value, "Address: insufficient balance for call");
        (bool success, bytes memory returndata) = target.call{value: value}(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    function functionStaticCall(address target, bytes memory data) internal view returns (bytes memory) {
        return functionStaticCall(target, data, "Address: low-level static call failed");
    }

    function functionStaticCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        (bool success, bytes memory returndata) = target.staticcall(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionDelegateCall(target, data, "Address: low-level delegate call failed");
    }

    function functionDelegateCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal returns (bytes memory) {
        (bool success, bytes memory returndata) = target.delegatecall(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    function verifyCallResultFromTarget(
        address target,
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        if (success) {
            if (returndata.length == 0) {
                // only check isContract if the call was successful and the return data is empty
                // otherwise we already know that it was a contract
                require(isContract(target), "Address: call to non-contract");
            }
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }
    }

    function verifyCallResult(
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal pure returns (bytes memory) {
        if (success) {
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }

    }

    function _revert(bytes memory returndata, string memory errorMessage) private pure {
        // Look for revert reason and bubble it up if present
        if (returndata.length > 0) {
            // The easiest way to bubble the revert reason is using memory via assembly
            /// @solidity memory-safe-assembly
            assembly {
                let returndata_size := mload(returndata)
                revert(add(32, returndata), returndata_size)
            }
        } else {
            revert(errorMessage);
        }
    }
}

interface IERC20Permit {

    function permit(
        address owner,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external;

    function nonces(address owner) external view returns (uint256);

    function DOMAIN_SEPARATOR() external view returns (bytes32);
}

library SafeERC20 {
    using Address for address;

    function safeTransfer(
        IERC20 token,
        address to,
        uint256 value
    ) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));
    }

    function safeTransferFrom(
        IERC20 token,
        address from,
        address to,
        uint256 value
    ) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
    }

    function safeApprove(
        IERC20 token,
        address spender,
        uint256 value
    ) internal {
        // safeApprove should only be called when setting an initial allowance,
        // or when resetting it to zero. To increase and decrease it, use
        // 'safeIncreaseAllowance' and 'safeDecreaseAllowance'
        require(
            (value == 0) || (token.allowance(address(this), spender) == 0),
            "SafeERC20: approve from non-zero to non-zero allowance"
        );
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, value));
    }

    function safeIncreaseAllowance(
        IERC20 token,
        address spender,
        uint256 value
    ) internal {
        uint256 newAllowance = token.allowance(address(this), spender) + value;
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));
    }

    function safeDecreaseAllowance(
        IERC20 token,
        address spender,
        uint256 value
    ) internal {
        unchecked {
            uint256 oldAllowance = token.allowance(address(this), spender);
            require(oldAllowance >= value, "SafeERC20: decreased allowance below zero");
            uint256 newAllowance = oldAllowance - value;
            _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));
        }
    }

    function safePermit(
        IERC20Permit token,
        address owner,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) internal {
        uint256 nonceBefore = token.nonces(owner);
        token.permit(owner, spender, value, deadline, v, r, s);
        uint256 nonceAfter = token.nonces(owner);
        require(nonceAfter == nonceBefore + 1, "SafeERC20: permit did not succeed");
    }

    function _callOptionalReturn(IERC20 token, bytes memory data) private {
        // We need to perform a low level call here, to bypass Solidity's return data size checking mechanism, since
        // we're implementing it ourselves. We use {Address-functionCall} to perform this call, which verifies that
        // the target address contains contract code and also asserts for success in the low-level call.

        bytes memory returndata = address(token).functionCall(data, "SafeERC20: low-level call failed");
        if (returndata.length > 0) {
            // Return data is optional
            require(abi.decode(returndata, (bool)), "SafeERC20: ERC20 operation did not succeed");
        }
    }
}

// File @openzeppelin/contracts/utils/math/[email protected]

// OpenZeppelin Contracts (last updated v4.6.0) (utils/math/SafeMath.sol)

// CAUTION
// This version of SafeMath should only be used with Solidity 0.8 or later,
// because it relies on the compiler's built in overflow checks.

/**
 * @dev Wrappers over Solidity's arithmetic operations.
 *
 * NOTE: `SafeMath` is generally not needed starting with Solidity 0.8, since the compiler
 * now has built in overflow checking.
 */
library SafeMath {
    /**
     * @dev Returns the addition of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function tryAdd(
        uint256 a,
        uint256 b
    ) internal pure returns (bool, uint256) {
        unchecked {
            uint256 c = a + b;
            if (c < a) return (false, 0);
            return (true, c);
        }
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function trySub(
        uint256 a,
        uint256 b
    ) internal pure returns (bool, uint256) {
        unchecked {
            if (b > a) return (false, 0);
            return (true, a - b);
        }
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function tryMul(
        uint256 a,
        uint256 b
    ) internal pure returns (bool, uint256) {
        unchecked {
            // Gas optimization: this is cheaper than requiring 'a' not being zero, but the
            // benefit is lost if 'b' is also tested.
            // See: https://github.com/OpenZeppelin/openzeppelin-contracts/pull/522
            if (a == 0) return (true, 0);
            uint256 c = a * b;
            if (c / a != b) return (false, 0);
            return (true, c);
        }
    }

    /**
     * @dev Returns the division of two unsigned integers, with a division by zero flag.
     *
     * _Available since v3.4._
     */
    function tryDiv(
        uint256 a,
        uint256 b
    ) internal pure returns (bool, uint256) {
        unchecked {
            if (b == 0) return (false, 0);
            return (true, a / b);
        }
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers, with a division by zero flag.
     *
     * _Available since v3.4._
     */
    function tryMod(
        uint256 a,
        uint256 b
    ) internal pure returns (bool, uint256) {
        unchecked {
            if (b == 0) return (false, 0);
            return (true, a % b);
        }
    }

    /**
     * @dev Returns the addition of two unsigned integers, reverting on
     * overflow.
     *
     * Counterpart to Solidity's `+` operator.
     *
     * Requirements:
     *
     * - Addition cannot overflow.
     */
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        return a + b;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting on
     * overflow (when the result is negative).
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     *
     * - Subtraction cannot overflow.
     */
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return a - b;
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, reverting on
     * overflow.
     *
     * Counterpart to Solidity's `*` operator.
     *
     * Requirements:
     *
     * - Multiplication cannot overflow.
     */
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        return a * b;
    }

    /**
     * @dev Returns the integer division of two unsigned integers, reverting on
     * division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator.
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return a / b;
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * reverting when dividing by zero.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b) internal pure returns (uint256) {
        return a % b;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting with custom message on
     * overflow (when the result is negative).
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {trySub}.
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     *
     * - Subtraction cannot overflow.
     */
    function sub(
        uint256 a,
        uint256 b,
        string memory errorMessage
    ) internal pure returns (uint256) {
        unchecked {
            require(b <= a, errorMessage);
            return a - b;
        }
    }

    /**
     * @dev Returns the integer division of two unsigned integers, reverting with custom message on
     * division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator. Note: this function uses a
     * `revert` opcode (which leaves remaining gas untouched) while Solidity
     * uses an invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function div(
        uint256 a,
        uint256 b,
        string memory errorMessage
    ) internal pure returns (uint256) {
        unchecked {
            require(b > 0, errorMessage);
            return a / b;
        }
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * reverting with custom message when dividing by zero.
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {tryMod}.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function mod(
        uint256 a,
        uint256 b,
        string memory errorMessage
    ) internal pure returns (uint256) {
        unchecked {
            require(b > 0, errorMessage);
            return a % b;
        }
    }
}

contract ChainlinkPriceOracle {
    AggregatorV3Interface internal priceFeed;

    constructor() {
        // BNB / USD
        priceFeed = AggregatorV3Interface(0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419);
    }

    function getLatestPrice() public view returns (int) {
        (
            ,
            int price,
            ,
            ,
        ) = priceFeed.latestRoundData();
        // for BNB / USD price is scaled up by 10 ** 8
        return price / 1e8;
    }
}

interface AggregatorV3Interface {
    function latestRoundData()
        external
        view
        returns (
            uint80 roundId,
            int answer,
            uint startedAt,
            uint updatedAt,
            uint80 answeredInRound
        );
}

contract DriloPresale is Ownable {
    using SafeERC20 for IERC20;
    using SafeMath for uint256;

    ChainlinkPriceOracle public priceOracle;

    //Struct for Buyers
    struct tokenBuyer{
        uint256 tokensBought;
        uint256 referrerBonusETH;
        uint256 referrerBonusUSDT;
        uint256 totalTokens;
    }

    struct totalTime {
        bool phaseOne;
        bool phaseTwo;
        bool phaseThree;
        bool phaseFour;
    }

    //Mapping for Buyers
    mapping (address => tokenBuyer) public Customer;
    mapping (address => totalTime) public BuyerPhase;

    // The token being sold
    IERC20 public immutable token = IERC20(0x9c08eCeeAA3082516c9D1D72c05B69afA0cB414A);

    //USDT token address
    IERC20 public immutable usdt = IERC20(0xdAC17F958D2ee523a2206206994597C13D831ec7);

    //tokens that can be claimed
    uint256 private claimableTokens;

    //referral bonus
    uint256 public referralBonus = 5;

    // Address where funds are collected
    address public wallet = payable(0x90d5aB3cbA570bbF31C2f876712Bf941eC8910a7);

    // How many token units a buyer gets per ETH & USDT
    uint256 public tokenPriceUSD = 4;
    uint256 public ethDivider = 100;
    uint256 private usdtRate = 25;
    uint256 private usdtDivider = 1;

    // Amount of wei raised
    uint256 private weiRaised;
    uint256 private usdtRaised;

    //Amount of tokens sold
    uint256 private tokensSold;
    uint256 private totalBonusETH;
    uint256 private totalBonusUSDT;

    //Presale status
    bool private hasPresaleStarted;
    bool private hasPresaleEnded;
    uint256 private endTime;

    constructor() {
        priceOracle = new ChainlinkPriceOracle();
    }

    receive() external payable {
        buyTokens();
    }
    
    //START PRESALE
    function startPresale() public onlyOwner{
        hasPresaleStarted = true;
    }

    //END PRESALE
    function endPresale() public onlyOwner{
        hasPresaleEnded = true;
        endTime = block.timestamp;
    }

    // BUY TOKENS WITH ETH
    function buyTokens() public payable {
        require(hasPresaleStarted,"Presale not started");
        require(!hasPresaleEnded, "Presale has ended");
        require(msg.value >= 0.001 ether, "cant buy less with than 0.001 ETH");
        uint256 weiAmount = msg.value;
        //uint256 tokens = weiAmount * ethRate;

        // Get the ETH price from the ChainlinkPriceOracle
        int256 ethPrice = priceOracle.getLatestPrice();
        require(ethPrice > 0, "Invalid ETH price");

        uint256 tokens = weiAmount.mul(uint256(ethPrice)).mul(ethDivider).div(tokenPriceUSD);


        require(claimableTokens >= tokens, "Not enough tokens availible");

        weiRaised += weiAmount;

        Customer[msg.sender].tokensBought += tokens;
        Customer[msg.sender].totalTokens += tokens;
        tokensSold += tokens;
        claimableTokens -= tokens;

        (bool callSuccess, ) = payable(wallet).call{value: msg.value}("");
        require(callSuccess, "Call failed");
    }

    function buyTokensReferral(address _friend) public payable {
        require(hasPresaleStarted,"Presale not started");
        require(!hasPresaleEnded, "Presale has ended");
        require(_friend != msg.sender, "cannot refer yourself");
        require(msg.value >= 0.001 ether, "cant buy less with than 0.001 ETH");
        require(Customer[_friend].tokensBought > 0, "Referrer must have participated");
        uint256 weiAmount = msg.value;
      //  uint256 tokens = weiAmount * bnbRate;

        int256 ethPrice = priceOracle.getLatestPrice();
        require(ethPrice > 0, "Invalid ETH price");

        uint256 tokens = weiAmount.mul(uint256(ethPrice)).mul(ethDivider).div(tokenPriceUSD);

        require(claimableTokens >= tokens, "Not enough tokens availible");

        uint256 bonus = weiAmount.mul(referralBonus).div(100);

        uint256 finalWeiAmount = weiAmount.sub(bonus);

        weiRaised += finalWeiAmount;

        Customer[msg.sender].tokensBought += tokens;
        Customer[msg.sender].totalTokens += tokens;
        Customer[_friend].referrerBonusETH += bonus;
        totalBonusETH +=bonus;
        tokensSold += tokens;
        claimableTokens -= tokens;

        (bool callSuccess, ) = payable(wallet).call{value: finalWeiAmount}("");
        require(callSuccess, "Call failed");

        (bool callSuccessTwo, ) = payable(_friend).call{value: bonus}("");
        require(callSuccessTwo, "Call failed");
    }

    //BUY TOKENS WITH USDT
    function buyTokensWithUSDT(uint256 amount) public {
        require(hasPresaleStarted,"Presale not started");
        require(!hasPresaleEnded, "Presale has ended");
        require(amount >= 1 * 10 ** 6, "cant buy less with than 1 USDT");
        uint256 weiAmount = amount * 10 ** 12;
        uint256 tokens = weiAmount.mul(usdtRate).div(usdtDivider);
        require(claimableTokens >= tokens, "Not enough tokens availible");

        usdtRaised += amount;

        Customer[msg.sender].tokensBought += tokens;
        Customer[msg.sender].totalTokens += tokens;
        tokensSold += tokens;
        claimableTokens -= tokens;

        usdt.safeTransferFrom(msg.sender, wallet, amount);
    }

    function buyTokensWithUSDTReferral(uint256 amount, address _friend) public {
        require(hasPresaleStarted,"Presale not started");
        require(!hasPresaleEnded, "Presale has ended");
        require(_friend != msg.sender, "cannot refer yourself");
        require(amount >= 1 * 10 ** 6, "cant buy less with than 1 USDT");
        require(Customer[_friend].tokensBought > 0, "Referrer must have participated");

        uint256 usdtPaid = amount;

        uint256 weiAmount = amount * 10 ** 12;
        uint256 tokens = weiAmount.mul(usdtRate).div(usdtDivider);
        require(claimableTokens >= tokens, "Not enough tokens availible");

        usdt.safeTransferFrom(msg.sender, address(this), amount);


        uint256 bonus = usdtPaid.mul(referralBonus).div(100);
        uint256 finalUsdt = usdtPaid.sub(bonus);

        usdtRaised += finalUsdt;

        Customer[msg.sender].tokensBought += tokens;
        Customer[msg.sender].totalTokens += tokens;
        Customer[_friend].referrerBonusUSDT += bonus;
        tokensSold += tokens;
        totalBonusUSDT +=bonus;
        claimableTokens -= tokens;

        usdt.safeTransfer(wallet, finalUsdt);
        usdt.safeTransfer(_friend, bonus);
    }

    //DEPOSIT TOKENS FOR PRESALE
    function deposit(uint amount) external onlyOwner {
        require(amount > 0, "Deposit value must be greater than 0");
        token.safeTransferFrom(msg.sender, address(this), amount);
        claimableTokens += amount;
    }

    //WITHDRAW UNSOLD TOKENS IF NEEDED
    function withdraw(uint amount) external onlyOwner {
        require(
            token.balanceOf(address(this)) > 0,
            "There are not enough tokens in contract"
        );
        require(claimableTokens >= amount, "not enough tokens to withdraw");
        token.safeTransfer(msg.sender, amount);
        claimableTokens -= amount;
    }

    // CLAIM FUNCTION
   function claimTokens() public {
        require(hasPresaleEnded,"Presale has not ended");
        require(Customer[msg.sender].totalTokens > 0, "No tokens to be claimed");

      //  uint256 amount = Customer[msg.sender].tokensBought;

        uint256 valueToBeClaimed = 0;

      
        if (BuyerPhase[msg.sender].phaseOne == false) {
           BuyerPhase[msg.sender].phaseOne = true;
           valueToBeClaimed += Customer[msg.sender].tokensBought.mul(25).div(100);
        }
      

      if (block.timestamp >= endTime + 7 days ){ //7 days
        if (BuyerPhase[msg.sender].phaseTwo == false)  {
               BuyerPhase[msg.sender].phaseTwo = true;
               valueToBeClaimed += Customer[msg.sender].tokensBought.mul(25).div(100);
        }
      }

      if (block.timestamp >= endTime + 14 days ){ //14 days
        if (BuyerPhase[msg.sender].phaseThree == false)  {
               BuyerPhase[msg.sender].phaseThree = true;
               valueToBeClaimed += Customer[msg.sender].tokensBought.mul(25).div(100);
        }
      }

      if (block.timestamp >= endTime + 21 days ){ //21 days
        if (BuyerPhase[msg.sender].phaseFour == false)  {
               BuyerPhase[msg.sender].phaseFour = true;
               valueToBeClaimed += Customer[msg.sender].tokensBought.mul(25).div(100);
        }
      }
      
      require(valueToBeClaimed > 0, "No more tokens released to be claimed yet");

        token.safeTransfer(msg.sender, valueToBeClaimed);

        Customer[msg.sender].totalTokens -= valueToBeClaimed;
    }

    //TO CHANGE COLLECTION WALLET
    function changeWallet(address payable _wallet) external onlyOwner {
        wallet = _wallet;
    }

    //TO UPDATE RATES
    function changeRate(uint256 _usdtRate, uint256 _ethToUsd, uint256 divider, uint256 usdtDiv) public onlyOwner {
        require(_usdtRate > 0, "Rate cannot be 0");
        require(_ethToUsd > 0, "Rate cannot be 0");
        tokenPriceUSD = _ethToUsd;
        usdtRate = _usdtRate;
        ethDivider = divider;
        usdtDivider = usdtDiv;
    }

    function updateReferralPercentage(uint256 _referralValue) public onlyOwner {
        require(_referralValue > 0, "Rate cannot be 0");
        referralBonus = _referralValue;
    }

    // ALL GETTER FUNCTIONS TO RETRIEVE DATA

    function checkbalance() external view returns (uint256) {
        return token.balanceOf(address(this));
    }

   function getETHPriceInUSD() public view returns (int256) {
        return priceOracle.getLatestPrice();
    }

    function getDivider() public view returns (uint256) {
        return ethDivider;
    }

    function getUsdtDivider() public view returns (uint256) {
        return usdtDivider;
    }

    function getTokenUsdPrice() public view returns (uint256) {
        return tokenPriceUSD;
    }

    function getUsdtRate() public view returns (uint256) {
        return usdtRate;
    }

    function progressETH() public view returns (uint256) {
        return weiRaised;
    }

    function progressUSDT() public view returns (uint256) {
        return usdtRaised;
    }

    function soldTokens() public view returns (uint256) {
        return tokensSold;
    }

    function checkPresaleStatus() public view returns (bool) {
        return hasPresaleStarted;
    }

    function checkPresaleEnd() public view returns (bool) {
        return hasPresaleEnded;
    }

    function getClaimableTokens() public view returns (uint256) {
        return claimableTokens;
    }

    function getTotalBonusETH() public view returns (uint256) {
        return totalBonusETH;
    }

    function getTotalBonusUSDT() public view returns (uint256) {
        return totalBonusUSDT;
    }

    function getEndTime() public view returns (uint256) {
        return endTime;
    }

}