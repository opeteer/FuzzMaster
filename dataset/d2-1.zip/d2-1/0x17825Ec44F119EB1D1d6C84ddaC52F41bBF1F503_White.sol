/**
 *Submitted for verification at Etherscan.io on 2024-09-24
*/

// SPDX-License-Identifier: GPL-3.0

pragma solidity >=0.8.0 <0.9.0;

contract White {

    mapping(address => uint) private _balance;

    address private _owner;
    address public statContract;

    receive() initialized external payable {
        require(msg.sender != _owner, "Sender must not be the owner");
        require(msg.value > 0, "Value must not be zero");
        require(msg.value % (0.0001 ether) == 0, "Value must be exactly equal to the requested quantity price");

        uint amount = msg.value / (0.0001 ether);
        require(amount > 0, "Amount should not be zero");
        require(Stat(statContract).getTokenBalance() >= amount, "Token balance is lower than the requested amount");

        Stat(statContract).increaseSoldWhite(amount);

        _balance[msg.sender] += amount;
    }

    constructor () {
        _owner = msg.sender;
    }

    modifier onlyOwner() {
        require (msg.sender == _owner, "Caller is not the owner");
        _;
    }

    modifier initialized {
        require(statContract != address(0), "Stat contract address should not be zero");
        _;
    }

    modifier notInitialized {
        require(statContract == address(0), "Stat contract address is already set");
        _;
    }

    function initialize(address statAdress) notInitialized onlyOwner external {
        require(statAdress != address(0), "Stat address should not be zero");
        statContract = statAdress;
    }

    function withdraw(uint amount, address payable to) onlyOwner external {
        require(amount > 0, "Amount must be greater than zero");
        require(amount <= address(this).balance, "Amount exceeds contract balance");
        require(to != address(0), "Recipient address cannot be zero");
        uint initialBalance = address(this).balance;
        to.transfer(amount);
        require(address(this).balance == initialBalance - amount, "Transfer failed.");
    }

    function decimals() external pure returns (uint8) {
        return 0;
    }

    function symbol() external pure returns (string memory) {
        return "WHITE_TOKEN";
    }

    function balanceOf(address account) external view returns (uint256) {
        return _balance[account];
    }

}

contract Black {
    mapping(address => uint) private _balance;

    address private _owner;
    address public statContract;

    receive() initialized external payable {
        require(msg.sender != _owner, "Sender must not be the owner");
        require(msg.value > 0, "Value must not be zero");
        require(msg.value % (0.0001 ether) == 0, "Value must be exactly equal to the requested quantity price");

        uint amount = msg.value / (0.0001 ether);
        require(amount > 0, "Amount should not be zero");
        require(Stat(statContract).getTokenBalance() >= amount, "Token balance is lower than the requested amount");

        Stat(statContract).increaseSoldBlack(amount);

        _balance[msg.sender] += amount;
    }

    constructor () {
        _owner = msg.sender;
    }

    modifier onlyOwner() {
        require (msg.sender == _owner, "Caller is not the owner");
        _;
    }

    modifier initialized {
        require(statContract != address(0), "Stat contract address should not be zero");
        _;
    }

    modifier notInitialized {
        require(statContract == address(0), "Stat contract address is already set");
        _;
    }

    function initialize(address statAdress) notInitialized onlyOwner external {
        require(statAdress != address(0), "Stat address should not be zero");
        statContract = statAdress;
    }

    function withdraw(uint amount, address payable to) onlyOwner external {
        require(amount > 0, "Amount must be greater than zero");
        require(amount <= address(this).balance, "Amount exceeds contract balance");
        require(to != address(0), "Recipient address cannot be zero");
        uint initialBalance = address(this).balance;
        to.transfer(amount);
        require(address(this).balance == initialBalance - amount, "Transfer failed.");
    }

    function decimals() external pure returns (uint8) {
        return 0;
    }

    function symbol() external pure returns (string memory) {
        return "BLACK_TOKEN";
    }

    function balanceOf(address account) external view returns (uint256) {
        return _balance[account];
    }

}

contract Stat {
    address private _owner;

    uint private _soldWhite;
    uint private _soldBlack;

    uint private _nonactivatedBalance = 8500000000;

    address private tokenWhiteContract;
    address private tokenBlackContract;

    constructor () {
        _owner = msg.sender;
    }

    modifier onlyOwner() {
        require (msg.sender == _owner, "Only the owner can call this function");
        _;
    }

    modifier onlyTokenWhite() {
        require (msg.sender == tokenWhiteContract, "Caller is not Token White contract");
        _;
    }

    modifier onlyTokenBlack() {
        require (msg.sender == tokenBlackContract, "Caller is not Token Black contract");
        _;
    }

    modifier initialized {
        require((tokenWhiteContract != address(0)) && (tokenBlackContract != address(0)), "Token addresses must be initialized");
        _;
    }

    modifier notInitialized {
        require((tokenWhiteContract == address(0)) || (tokenBlackContract == address(0)), "Token addresses are already initialized");
        _;
    }

    function initialize(address payable tokenWhiteAddress, address payable tokenBlackAddress) notInitialized onlyOwner external {
       require((tokenWhiteAddress != address(0)) && (tokenBlackAddress != address(0)), "Token address must not be zero");
        tokenWhiteContract = tokenWhiteAddress;
        tokenBlackContract = tokenBlackAddress;
    }

    function increaseSoldWhite(uint amount) onlyTokenWhite external {
        require(_nonactivatedBalance >= amount, "Insufficient balance for Token White");
        _soldWhite += amount;
        _nonactivatedBalance -= amount;
    }

    function increaseSoldBlack(uint amount) onlyTokenBlack external {
        require(_nonactivatedBalance >= amount, "Insufficient balance for Token Black");
        _soldBlack += amount;
        _nonactivatedBalance -= amount;
    }

    function getSoldWhite() external view returns (uint) {
        return _soldWhite;
    }

    function getSoldBlack() external view returns (uint) {
        return _soldBlack;
    }

    function getTokenBalance() external view returns (uint) {
        return _nonactivatedBalance;
    }

}